/* Deloris Canvas UI kit — stateful workspace app. */
const A = window.DelorisDesignSystem_e3c294;
const UI = { Icon: window.Icon, Sidebar: window.Sidebar, TopBar: window.TopBar, Inspector: window.Inspector, LayeredView: window.LayeredView };
const NODE_W = 200;

const seedNodes = [
{ id: "n1", title: "Market data", kind: "Source", accent: "clay", x: 80, y: 90, layer: 0, value: "" },
{ id: "n2", title: "Customer signals", kind: "Source", accent: "clay", x: 80, y: 250, layer: 0, value: "" },
{ id: "n3", title: "Revenue forecast", kind: "Metric", accent: "blue", x: 400, y: 110, layer: 1, value: "$1.24M" },
{ id: "n4", title: "Churn rate", kind: "Metric", accent: "blue", x: 400, y: 280, layer: 1, value: "3.1%" },
{ id: "n5", title: "Growth thesis", kind: "Theme", accent: "plum", x: 720, y: 190, layer: 2, value: "" }];

const seedEdges = [
{ from: "n1", to: "n3", label: "feeds", active: true },
{ from: "n2", to: "n4", label: "drives" },
{ from: "n3", to: "n5", label: "supports" },
{ from: "n4", to: "n5", label: "tempers" }];


function CanvasFlat({ nodes, edges, selected, onSelect, onDragNode, dragId, zoom, present }) {
  const byId = Object.fromEntries(nodes.map((n) => [n.id, n]));
  const anchor = (n, side) => ({ x: n.x + (side === "out" ? NODE_W : 0), y: n.y + 42 });
  return (
    <div style={{
      position: "absolute", inset: 0, overflow: "hidden",
      background: "var(--canvas-bg)",
      backgroundImage: "linear-gradient(var(--canvas-grid) 1px,transparent 1px),linear-gradient(90deg,var(--canvas-grid) 1px,transparent 1px)",
      backgroundSize: "var(--canvas-grid-size) var(--canvas-grid-size)"
    }}
    onPointerDown={(e) => {if (e.target === e.currentTarget) onSelect(null);}}>
      
      <div style={{ position: "absolute", left: 0, top: 0, width: "100%", height: "100%", transform: `scale(${zoom})`, transformOrigin: "0 0", transition: "transform var(--dur-base) var(--ease-soft)" }}>
        {edges.map((e, i) => {
          const a = byId[e.from],b = byId[e.to];
          if (!a || !b) return null;
          return <A.Connection key={i} from={anchor(a, "out")} to={anchor(b, "in")} label={present ? undefined : e.label} active={e.active || a.id === selected || b.id === selected} />;
        })}
        {nodes.map((n) =>
        <A.Node key={n.id} title={n.title} kind={n.kind} accent={n.accent}
        meta={present ? undefined : null}
        selected={!present && n.id === selected} dragging={n.id === dragId} showHandles={!present}
        onPointerDown={(e) => {e.stopPropagation();onSelect(n.id);onDragNode(e, n.id);}}
        style={{ position: "absolute", left: n.x, top: n.y, width: NODE_W }}>
            {n.value ? <span style={{ font: "var(--type-data)", color: "var(--text-strong)", fontSize: "16px" }}>{n.value}</span> : null}
          </A.Node>
        )}
      </div>
    </div>);

}

function App() {
  const [nodes, setNodes] = React.useState(seedNodes);
  const [edges, setEdges] = React.useState(seedEdges);
  const [selected, setSelected] = React.useState("n3");
  const [view, setView] = React.useState("flat");
  const [layerVis, setLayerVis] = React.useState({ 0: true, 1: true, 2: true });
  const [zoom, setZoom] = React.useState(1);
  const [dragId, setDragId] = React.useState(null);
  const drag = React.useRef(null);

  React.useEffect(() => {if (window.lucide) window.lucide.createIcons();});

  const onDragNode = (e, id) => {
    const start = { px: e.clientX, py: e.clientY };
    const node = nodes.find((n) => n.id === id);
    drag.current = { id, ...start, ox: node.x, oy: node.y };
    setDragId(id);
    const move = (ev) => {
      const d = drag.current;if (!d) return;
      const nx = d.ox + (ev.clientX - d.px) / zoom;
      const ny = d.oy + (ev.clientY - d.py) / zoom;
      setNodes((ns) => ns.map((n) => n.id === d.id ? { ...n, x: Math.max(0, nx), y: Math.max(0, ny) } : n));
    };
    const up = () => {drag.current = null;setDragId(null);window.removeEventListener("pointermove", move);window.removeEventListener("pointerup", up);};
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  };

  const updateNode = (id, patch) => setNodes((ns) => ns.map((n) => n.id === id ? { ...n, ...patch, layer: patch.accent ? { clay: 0, blue: 1, plum: 2, neutral: n.layer }[patch.accent] : n.layer } : n));
  const deleteNode = (id) => {setNodes((ns) => ns.filter((n) => n.id !== id));setEdges((es) => es.filter((e) => e.from !== id && e.to !== id));setSelected(null);};
  const addNode = () => {
    const id = "n" + Date.now();
    setNodes((ns) => [...ns, { id, title: "New node", kind: "Source", accent: "clay", x: 120 + Math.random() * 120, y: 120 + Math.random() * 120, layer: 0, value: "" }]);
    setSelected(id);
  };

  const visibleNodes = nodes.filter((n) => layerVis[n.layer]);
  const summary = {
    nodes: nodes.length, edges: edges.length,
    byLayer: window.LAYERS.map((l) => ({ label: l.name, value: nodes.filter((n) => n.layer === l.id).length, color: l.color }))
  };
  const present = view === "present";
  const selNode = nodes.find((n) => n.id === selected);

  return (
    <div data-theme={present ? "presentation" : undefined} style={{ display: "flex", height: "100vh", width: "100vw", background: "var(--bg-app)", fontFamily: "var(--font-sans)", overflow: "hidden", transition: "background-color var(--dur-slow) var(--ease-soft)" }}>
      {!present && <UI.Sidebar canvases={CANVASES} current="c1" onSelect={() => {}} layerVis={layerVis} onToggleLayer={(id) => setLayerVis((v) => ({ ...v, [id]: !v[id] }))} />}
      <div style={{ flex: 1, display: "flex", flexDirection: "column", minWidth: 0 }}>
        {!present && <UI.TopBar title="Strategy map" view={view} onView={setView} count={nodes.length} />}
        <div style={{ flex: 1, position: "relative" }}>
          {view === "layered" ?
          <UI.LayeredView nodes={visibleNodes} edges={edges} layerVis={layerVis} /> :
          <CanvasFlat nodes={visibleNodes} edges={edges} selected={selected} onSelect={setSelected} onDragNode={onDragNode} dragId={dragId} zoom={present ? 1.05 : zoom} present={present} />}

          {!present && view !== "layered" &&
          <div style={{ position: "absolute", left: "50%", bottom: 20, transform: "translateX(-50%)" }}>
              <A.Toolbar>
                <A.IconButton active label="Select"><UI.Icon n="mouse-pointer-2" /></A.IconButton>
                <A.IconButton label="Pan"><UI.Icon n="hand" /></A.IconButton>
                <A.Toolbar.Divider />
                <A.IconButton label="Add node" onClick={addNode}><UI.Icon n="square-plus" /></A.IconButton>
                <A.IconButton label="Connect"><UI.Icon n="spline" /></A.IconButton>
                <A.IconButton label="Comment"><UI.Icon n="message-circle" /></A.IconButton>
                <A.Toolbar.Divider />
                <A.IconButton label="Zoom out" onClick={() => setZoom((z) => Math.max(0.5, +(z - 0.1).toFixed(2)))}><UI.Icon n="minus" /></A.IconButton>
                <A.IconButton label="Zoom in" onClick={() => setZoom((z) => Math.min(1.6, +(z + 0.1).toFixed(2)))}><UI.Icon n="plus" /></A.IconButton>
              </A.Toolbar>
            </div>
          }

          {present &&
          <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, padding: "20px 28px", display: "flex", alignItems: "center", justifyContent: "space-between", background: "linear-gradient(to top, rgba(20,18,15,0.55), transparent)" }}>
              <div>
                <div style={{ fontFamily: "var(--font-serif)", fontSize: 26, fontWeight: 600, color: "var(--text-strong)" }}>Strategy map</div>
                <div style={{ font: "var(--type-caption)", color: "var(--text-muted)" }}>{nodes.length} nodes · {edges.length} connections</div>
              </div>
              <A.Button variant="secondary" size="sm" iconLeft={<UI.Icon n="x" s={15} />} onClick={() => setView("flat")}>Exit presentation</A.Button>
            </div>
          }
        </div>
      </div>
      {!present && <UI.Inspector node={selNode} onChange={updateNode} onDelete={deleteNode} edges={edges} summary={summary} />}
    </div>);

}

const CANVASES = [
{ id: "c1", name: "Strategy map", icon: "git-fork", count: 5 },
{ id: "c2", name: "Q3 planning", icon: "calendar", count: 12 },
{ id: "c3", name: "Risk model", icon: "shield-alert", count: 8 },
{ id: "c4", name: "Org topics", icon: "network", count: 21 }];


ReactDOM.createRoot(document.getElementById("root")).render(<App />);