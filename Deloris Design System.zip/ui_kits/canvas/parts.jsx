/* Deloris Canvas UI kit — presentational parts (Sidebar, TopBar, Inspector, LayeredView).
   Shares the design-system bundle via window.DelorisDesignSystem_e3c294.
   Exports to window for the sibling app.jsx (separate babel scope). */
const NS = window.DelorisDesignSystem_e3c294;
const Icon = ({ n, s = 16, color }) => <i data-lucide={n} style={{ width: s, height: s, display: "inline-flex", color }}></i>;

const LAYERS = [
  { id: 0, name: "Sources", accent: "green", color: "var(--green-500)" },
  { id: 1, name: "Metrics", accent: "slate", color: "var(--slate-500)" },
  { id: 2, name: "Themes", accent: "stone", color: "var(--stone-500)" },
];

function Wordmark({ size = 22 }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
      <span style={{
        width: 26, height: 26, borderRadius: 7, background: "var(--green-500)", color: "#fff",
        display: "inline-flex", alignItems: "center", justifyContent: "center",
        fontFamily: "var(--font-display)", fontWeight: 600, fontSize: 17, boxShadow: "var(--shadow-sm)",
      }}>D</span>
      <span style={{ fontFamily: "var(--font-display)", fontSize: size, fontWeight: 600, color: "var(--text-strong)", letterSpacing: "-0.01em" }}>Deloris</span>
    </div>
  );
}

function Sidebar({ canvases, current, onSelect, layerVis, onToggleLayer }) {
  return (
    <aside style={{
      width: "var(--sidebar-w)", flex: "none", background: "var(--bg-panel)",
      borderRight: "1px solid var(--border-default)", display: "flex", flexDirection: "column",
      height: "100%", boxSizing: "border-box",
    }}>
      <div style={{ padding: "18px 18px 14px" }}><Wordmark /></div>
      <div style={{ padding: "0 14px 12px" }}>
        <NS.Input iconLeft={<Icon n="search" />} placeholder="Search canvas" size="sm" />
      </div>
      <div style={{ padding: "6px 14px", overflowY: "auto", flex: 1 }}>
        <SideLabel>Canvases</SideLabel>
        <div style={{ display: "flex", flexDirection: "column", gap: 2, marginBottom: 18 }}>
          {canvases.map((c) => (
            <button key={c.id} onClick={() => onSelect(c.id)} style={{
              display: "flex", alignItems: "center", gap: 9, padding: "8px 10px", border: "none",
              borderRadius: "var(--radius-sm)", cursor: "pointer", textAlign: "left", width: "100%",
              background: c.id === current ? "var(--accent-soft)" : "transparent",
              color: c.id === current ? "var(--accent)" : "var(--text-body)",
              font: "var(--type-label)", transition: "var(--transition-control)",
            }}>
              <Icon n={c.icon} s={15} />
              <span style={{ flex: 1 }}>{c.name}</span>
              <span style={{ font: "var(--type-mono)", fontSize: 11, color: "var(--text-faint)" }}>{c.count}</span>
            </button>
          ))}
        </div>
        <SideLabel>Layers</SideLabel>
        <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
          {LAYERS.map((l) => (
            <div key={l.id} style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 10px", borderRadius: "var(--radius-sm)" }}>
              <span style={{ width: 9, height: 9, borderRadius: 3, background: l.color, flex: "none" }} />
              <span style={{ flex: 1, font: "var(--type-label)", color: "var(--text-body)" }}>{l.name}</span>
              <button onClick={() => onToggleLayer(l.id)} style={{ border: "none", background: "transparent", cursor: "pointer", color: "var(--text-faint)", display: "inline-flex", padding: 2 }}>
                <Icon n={layerVis[l.id] ? "eye" : "eye-off"} s={15} />
              </button>
            </div>
          ))}
        </div>
      </div>
      <div style={{ padding: 14, borderTop: "1px solid var(--border-default)", display: "flex", alignItems: "center", gap: 10 }}>
        <span style={{ width: 30, height: 30, borderRadius: "50%", background: "var(--stone-300)", color: "#fff", display: "inline-flex", alignItems: "center", justifyContent: "center", font: "var(--type-label)" }}>JJ</span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ font: "var(--type-label)", color: "var(--text-strong)" }}>Jone J.</div>
          <div style={{ font: "var(--type-caption)", color: "var(--text-faint)" }}>Workspace</div>
        </div>
        <Icon n="settings" s={16} color="var(--text-faint)" />
      </div>
    </aside>
  );
}

const SideLabel = ({ children }) => (
  <div style={{ font: "var(--type-overline)", letterSpacing: "var(--tracking-caps)", textTransform: "uppercase", color: "var(--text-faint)", padding: "0 10px 8px" }}>{children}</div>
);

function TopBar({ title, view, onView, count }) {
  return (
    <header style={{
      height: "var(--toolbar-h)", flex: "none", display: "flex", alignItems: "center",
      gap: 16, padding: "0 18px", borderBottom: "1px solid var(--border-default)",
      background: "var(--bg-app)",
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, minWidth: 0 }}>
        <span style={{ font: "var(--type-heading)", color: "var(--text-strong)", whiteSpace: "nowrap" }}>{title}</span>
        <NS.Badge tone="neutral">{count} nodes</NS.Badge>
      </div>
      <div style={{ flex: 1, display: "flex", justifyContent: "center" }}>
        <NS.SegmentedControl value={view} onChange={onView} items={[
          { id: "flat", label: "Flat", icon: <Icon n="layout-grid" s={14} /> },
          { id: "layered", label: "Layered", icon: <Icon n="layers" s={14} /> },
          { id: "present", label: "Present", icon: <Icon n="presentation" s={14} /> },
        ]} />
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <NS.IconButton label="Comments"><Icon n="message-circle" /></NS.IconButton>
        <NS.IconButton label="History"><Icon n="history" /></NS.IconButton>
        <NS.Button variant="secondary" size="sm" iconLeft={<Icon n="share-2" s={15} />}>Share</NS.Button>
      </div>
    </header>
  );
}

Object.assign(window, { NS, Icon, LAYERS, Wordmark, Sidebar, TopBar, SideLabel });
