# Canvas workspace — Deloris UI kit

The hero surface: an infinite **fine line-grid canvas** where information lives as draggable paper **nodes** joined by smooth **bezier connections**. Recreates the core Deloris product view.

## Screens / behavior
- **Flat view** — drag nodes, select to edit in the inspector, add nodes from the toolbar, zoom in/out. Connections highlight when either endpoint is selected.
- **Layered view** — the same data and topics restacked as translucent 3D planes by layer (Sources → Metrics → Themes), for seeing relations across depth.
- **Presentation view** — chrome (sidebar, inspector, toolbar) drops away, the warm presentation theme takes over, and the canvas is shown clean for an audience. Exit via the floating control.

## Files
- `index.html` — entry; loads the DS bundle then the three babel scripts.
- `parts.jsx` — `Sidebar`, `TopBar`, `Wordmark` (exported to `window`).
- `inspector.jsx` — `Inspector` (node properties / overview) and `LayeredView`.
- `app.jsx` — stateful `App`: node/edge state, pointer-drag, zoom, view switching.

## Composition
Built from the system's own primitives via `window.DelorisDesignSystem_e3c294`: `Node`, `Connection`, `Toolbar`, `IconButton`, `Button`, `Input`, `Badge`, `SegmentedControl`, `StatCard`, `MetricBars`. Icons are Lucide (CDN).
