/* Deloris Canvas UI kit — right inspector + layered (3D) view. */
const _NS = window.DelorisDesignSystem_e3c294;
const _Icon = window.Icon;

function Inspector({ node, onChange, onDelete, edges, summary }) {
  if (!node) {
    return (
      <aside style={inspectorShell}>
        <div style={{ padding: "18px 18px 14px", borderBottom: "1px solid var(--border-default)" }}>
          <div style={{ font: "var(--type-heading)", color: "var(--text-strong)" }}>Overview</div>
          <div style={{ font: "var(--type-caption)", color: "var(--text-muted)", marginTop: 2 }}>Select a node to edit it</div>
        </div>
        <div style={{ padding: 18, display: "flex", flexDirection: "column", gap: 12 }}>
          <_NS.StatCard label="Nodes" value={summary.nodes} accent="green" />
          <_NS.StatCard label="Connections" value={summary.edges} accent="slate" />
          <div style={{ background: "var(--bg-panel)", border: "1px solid var(--border-default)", borderRadius: "var(--radius-md)", padding: 14 }}>
            <div style={{ font: "var(--type-overline)", letterSpacing: "var(--tracking-wide)", textTransform: "uppercase", color: "var(--text-faint)", marginBottom: 10 }}>Coverage by layer</div>
            <_NS.MetricBars unit="" data={summary.byLayer} />
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "flex-start", padding: "10px 12px", background: "var(--accent-soft)", borderRadius: "var(--radius-sm)" }}>
            <_Icon n="lightbulb" s={15} color="var(--green-600)" />
            <span style={{ font: "var(--type-caption)", color: "var(--green-700)" }}>Drag from a node handle to draw a connection. Switch to Layered to see relations by depth.</span>
          </div>
        </div>
      </aside>
    );
  }
  const accents = [["green", "var(--green-500)"], ["slate", "var(--slate-500)"], ["stone", "var(--stone-500)"], ["neutral", "var(--ink-3)"]];
  const related = edges.filter((e) => e.from === node.id || e.to === node.id);
  return (
    <aside style={inspectorShell}>
      <div style={{ padding: "16px 18px", borderBottom: "1px solid var(--border-default)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <_NS.Badge tone={node.accent === "neutral" ? "neutral" : node.accent}>{node.kind}</_NS.Badge>
        <_NS.IconButton label="Delete node" size="sm" onClick={() => onDelete(node.id)}><_Icon n="trash-2" s={15} /></_NS.IconButton>
      </div>
      <div style={{ padding: 18, display: "flex", flexDirection: "column", gap: 16, overflowY: "auto" }}>
        <_NS.Input label="Title" value={node.title} onChange={(e) => onChange(node.id, { title: e.target.value })} />
        <div>
          <div style={{ font: "var(--type-label)", color: "var(--text-body)", marginBottom: 8 }}>Layer accent</div>
          <div style={{ display: "flex", gap: 8 }}>
            {accents.map(([name, col]) => (
              <button key={name} onClick={() => onChange(node.id, { accent: name })} style={{
                width: 30, height: 30, borderRadius: "50%", background: col, cursor: "pointer",
                border: node.accent === name ? "2px solid var(--text-strong)" : "2px solid transparent",
                outline: node.accent === name ? "2px solid var(--surface-card)" : "none", outlineOffset: -4,
              }} />
            ))}
          </div>
        </div>
        <_NS.Input label="Value" value={node.value || ""} onChange={(e) => onChange(node.id, { value: e.target.value })} placeholder="e.g. $1.24M" />
        <div>
          <div style={{ font: "var(--type-label)", color: "var(--text-body)", marginBottom: 8 }}>Connections · {related.length}</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            {related.length === 0 ? <span style={{ font: "var(--type-caption)", color: "var(--text-faint)" }}>No connections yet</span> :
              related.map((e, i) => (
                <div key={i} style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 10px", background: "var(--bg-panel)", borderRadius: "var(--radius-sm)" }}>
                  <_Icon n="spline" s={14} color="var(--text-faint)" />
                  <span style={{ flex: 1, font: "var(--type-caption)", color: "var(--text-body)" }}>{e.label || "linked"}</span>
                  <span style={{ font: "var(--type-mono)", fontSize: 11, color: "var(--text-faint)" }}>{e.from === node.id ? "out" : "in"}</span>
                </div>
              ))}
          </div>
        </div>
      </div>
    </aside>
  );
}

const inspectorShell = {
  width: "var(--inspector-w)", flex: "none", background: "var(--bg-app)",
  borderLeft: "1px solid var(--border-default)", display: "flex", flexDirection: "column", height: "100%", boxSizing: "border-box",
};

/* ── Layered / 3D depth view ── stacked translucent planes by layer */
function LayeredView({ nodes, edges, layerVis }) {
  const planes = window.LAYERS;
  return (
    <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", perspective: 1600, overflow: "hidden" }}>
      <div style={{ position: "relative", width: 560, height: 360, transformStyle: "preserve-3d", transform: "rotateX(50deg) rotateZ(-30deg)" }}>
        {planes.map((p, i) => {
          if (!layerVis[p.id]) return null;
          const layerNodes = nodes.filter((n) => n.layer === p.id);
          return (
            <div key={p.id} style={{
              position: "absolute", inset: 0, transform: `translateZ(${i * 90}px)`,
              background: "color-mix(in srgb, var(--surface-card) 86%, transparent)",
              border: `1.5px solid ${p.color}`, borderRadius: 16,
              boxShadow: "0 30px 50px rgba(58,52,45,0.16)",
              backgroundImage: "linear-gradient(var(--canvas-grid) 1px,transparent 1px),linear-gradient(90deg,var(--canvas-grid) 1px,transparent 1px)",
              backgroundSize: "28px 28px",
            }}>
              <div style={{ position: "absolute", top: 10, left: 14, font: "var(--type-overline)", letterSpacing: "var(--tracking-wide)", textTransform: "uppercase", color: p.color }}>{p.name}</div>
              {layerNodes.map((n) => (
                <div key={n.id} style={{
                  position: "absolute", left: (n.x % 380) + 60, top: (n.y % 220) + 50,
                  padding: "7px 11px", background: "var(--surface-white)", border: `1px solid ${p.color}`,
                  borderRadius: 8, boxShadow: "0 6px 14px rgba(58,52,45,0.18)", whiteSpace: "nowrap",
                  font: "var(--type-label)", fontSize: 12, color: "var(--text-strong)",
                }}>{n.title}</div>
              ))}
            </div>
          );
        })}
      </div>
      <div style={{ position: "absolute", bottom: 22, left: "50%", transform: "translateX(-50%)", font: "var(--type-caption)", color: "var(--text-muted)", background: "var(--surface-card)", border: "1px solid var(--border-default)", borderRadius: "var(--radius-pill)", padding: "6px 14px", boxShadow: "var(--shadow-sm)" }}>
        Relations stacked by layer — Sources feed Metrics feed Themes
      </div>
    </div>
  );
}

Object.assign(window, { Inspector, LayeredView });
