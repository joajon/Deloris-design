# Insights dashboard — Deloris UI kit

A calm statistics view over the canvas data: KPI stat cards, a trend, layer-coverage bars, and a scannable **topics table** with health, status, and selection. A **Presentation** switch drops the chrome and shifts to the warm presentation theme for showing to an audience.

## Files
- `index.html` — entry; loads the DS bundle then `app.jsx`.
- `app.jsx` — stateful dashboard (row selection, time range, presentation toggle).

## Composition
Uses `window.DelorisDesignSystem_e3c294`: `StatCard`, `MetricBars`, `DataTable`, `Badge`, `Button`, `Switch`, `SegmentedControl`. The trend bars are plain divs (no chart lib). Icons are Lucide (CDN).
