/* Deloris Insights UI kit — stats dashboard + table over the canvas data. */
const D = window.DelorisDesignSystem_e3c294;
const Ic = ({ n, s = 16, color }) => <i data-lucide={n} style={{ width: s, height: s, display: "inline-flex", color }}></i>;

const TOPICS = [
  { id: 1, topic: "Market data", layer: "Sources", nodes: 42, links: 18, health: 96, status: "Synced", updated: "2m ago" },
  { id: 2, topic: "Customer signals", layer: "Sources", nodes: 28, links: 11, health: 88, status: "Synced", updated: "14m ago" },
  { id: 3, topic: "Revenue forecast", layer: "Metrics", nodes: 31, links: 22, health: 74, status: "Review", updated: "1h ago" },
  { id: 4, topic: "Churn rate", layer: "Metrics", nodes: 17, links: 9, health: 91, status: "Synced", updated: "3h ago" },
  { id: 5, topic: "Growth thesis", layer: "Themes", nodes: 12, links: 14, health: 63, status: "Review", updated: "1d ago" },
  { id: 6, topic: "Risk model", layer: "Themes", nodes: 24, links: 7, health: 81, status: "Synced", updated: "2d ago" },
];

function Panel({ title, action, children, style }) {
  return (
    <div style={{ background: "var(--surface-card)", border: "1px solid var(--border-default)", borderRadius: "var(--radius-md)", boxShadow: "var(--shadow-sm)", ...style }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "16px 18px 0" }}>
        <span style={{ font: "var(--type-heading)", fontSize: 16, color: "var(--text-strong)" }}>{title}</span>
        {action}
      </div>
      <div style={{ padding: 18 }}>{children}</div>
    </div>
  );
}

function App() {
  const [selected, setSelected] = React.useState(3);
  const [present, setPresent] = React.useState(false);
  const [range, setRange] = React.useState("30d");
  React.useEffect(() => { if (window.lucide) window.lucide.createIcons(); });

  const statusCell = (v) => <D.Badge tone={v === "Synced" ? "success" : "warning"} dot>{v}</D.Badge>;
  const healthCell = (v) => (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 8, justifyContent: "flex-end", width: "100%" }}>
      <span style={{ width: 46, height: 6, borderRadius: 999, background: "var(--bg-sunken)", overflow: "hidden", display: "inline-block" }}>
        <span style={{ display: "block", height: "100%", width: v + "%", background: v > 85 ? "var(--success-500)" : v > 70 ? "var(--warning-500)" : "var(--danger-500)", borderRadius: 999 }} />
      </span>
      <span style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>{v}</span>
    </span>
  );

  return (
    <div data-theme={present ? "presentation" : undefined} style={{ minHeight: "100vh", background: "var(--bg-app)", fontFamily: "var(--font-sans)", transition: "background-color var(--dur-slow) var(--ease-soft)" }}>
      <div style={{ maxWidth: 1080, margin: "0 auto", padding: present ? "48px 40px" : "28px 32px" }}>
        {/* header */}
        <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: 16, marginBottom: 22 }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 9, marginBottom: 6 }}>
              <span style={{ width: 24, height: 24, borderRadius: 6, background: "var(--green-500)", color: "#fff", display: "inline-flex", alignItems: "center", justifyContent: "center", fontFamily: "var(--font-display)", fontWeight: 600, fontSize: 15 }}>D</span>
              <span style={{ font: "var(--type-overline)", letterSpacing: "var(--tracking-caps)", textTransform: "uppercase", color: "var(--text-faint)" }}>Insights</span>
            </div>
            <h1 style={{ margin: 0, fontFamily: "var(--font-display)", fontWeight: 600, fontSize: present ? 42 : 34, color: "var(--text-strong)", letterSpacing: "-0.01em" }}>Strategy map overview</h1>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            {!present && <D.SegmentedControl size="sm" value={range} onChange={setRange} items={[{ id: "7d", label: "7d" }, { id: "30d", label: "30d" }, { id: "qtr", label: "Quarter" }]} />}
            <D.Switch checked={present} onChange={setPresent} label="Presentation" />
          </div>
        </div>

        {/* stat row */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 14, marginBottom: 16 }}>
          <D.StatCard label="Total nodes" value="248" delta="12%" trend="up" />
          <D.StatCard label="Connections" value="612" delta="6%" trend="up" accent="slate" />
          <D.StatCard label="Avg. health" value="82" unit="%" delta="1.4" trend="down" accent="stone" />
          <D.StatCard label="In review" value="2" delta="1" trend="down" footnote="topics flagged" />
        </div>

        {/* chart + bars */}
        <div style={{ display: "grid", gridTemplateColumns: "1.5fr 1fr", gap: 16, marginBottom: 16 }}>
          <Panel title="Nodes added" action={<D.Badge tone="green">{range}</D.Badge>}>
            <Trend />
          </Panel>
          <Panel title="Coverage by layer">
            <D.MetricBars data={[
              { label: "Sources", value: 70, color: "var(--green-500)" },
              { label: "Metrics", value: 48, color: "var(--slate-500)" },
              { label: "Themes", value: 36, color: "var(--stone-500)" },
            ]} />
          </Panel>
        </div>

        {/* table */}
        <Panel title="Topics" action={!present && <D.Button variant="secondary" size="sm" iconLeft={<Ic n="sliders-horizontal" s={14} />}>Filter</D.Button>}>
          <D.DataTable
            selectable selectedId={selected} onRowClick={(r) => setSelected(r.id)}
            columns={[
              { key: "topic", label: "Topic", render: (v, r) => <span style={{ display: "inline-flex", alignItems: "center", gap: 9 }}><span style={{ width: 8, height: 8, borderRadius: 3, background: r.layer === "Sources" ? "var(--green-500)" : r.layer === "Metrics" ? "var(--slate-500)" : "var(--stone-500)" }} />{v}</span> },
              { key: "layer", label: "Layer" },
              { key: "nodes", label: "Nodes", align: "right", mono: true },
              { key: "links", label: "Links", align: "right", mono: true },
              { key: "health", label: "Health", align: "right", render: healthCell },
              { key: "status", label: "Status", render: statusCell },
              { key: "updated", label: "Updated", align: "right", render: (v) => <span style={{ color: "var(--text-faint)" }}>{v}</span> },
            ]}
            rows={TOPICS}
          />
        </Panel>
      </div>
    </div>
  );
}

/* tiny inline area-trend sparkline built from divs (no canvas) */
function Trend() {
  const pts = [12, 18, 15, 24, 22, 30, 27, 35, 33, 42, 40, 48];
  const max = Math.max(...pts);
  return (
    <div style={{ display: "flex", alignItems: "flex-end", gap: 6, height: 150 }}>
      {pts.map((p, i) => (
        <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "flex-end", height: "100%" }}>
          <div style={{ height: (p / max) * 100 + "%", background: i === pts.length - 1 ? "var(--green-500)" : "var(--green-100)", borderRadius: "4px 4px 2px 2px", transition: "height var(--dur-slow) var(--ease-out)" }} />
        </div>
      ))}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
