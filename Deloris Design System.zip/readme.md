# Deloris Design System

A design system for **HTML applications built around an information canvas** — workspaces where data and topics live as nodes, joined by drawn connections, alongside statistics and table views, all editable in place. Calm, minimal, near-monochrome, and quietly functional, with a **Presentation view** (deep-green dark mode) for showing work to others.

> Built for *Deloris* (repo `joajon/Deloris-design`, © Jone Joakimsen). The attached repo currently contains only a LICENSE, so this system was authored **from the written product brief**, not from existing code. As the product grows, point this system at the real components.

**Sources**
- GitHub: https://github.com/joajon/Deloris-design — explore for future iterations; nothing design-relevant is there yet beyond the license.
- Related repos in the same account worth a look when building features: `joajon/Norna` (state-assessment / past–present–future framing) and `joajon/Phantom`.

---

## What this is for
Canvas-first information apps: infinite **fine line-grid** boards of draggable nodes; smooth **bezier connections** between them; **statistics** (KPI cards, trends, bar coverage); **table views**; and live, in-place editing. Two extra view modes carry the brief:
- **Layered (3D)** — restack the same nodes as translucent depth planes by layer, to read relations across depth.
- **Presentation** — drop the editing chrome and switch to a deep muted-green dark theme to show the work to an audience.

---

## CONTENT FUNDAMENTALS
How Deloris writes.

- **Voice:** calm, plain, second-person. Address the user as *you* ("Select a node to edit it"). The product speaks softly and never shouts.
- **Tone:** unhurried and competent. Short, declarative sentences. Verbs over nouns ("Add node", "Draw a connection", "Show statistics").
- **Casing:** **Sentence case** everywhere — buttons, menus, headings, table cells ("Add node", "Revenue forecast", not "Add Node"). The only uppercase is the **overline** label style (tracked-out, for section eyebrows and table headers like `SOURCES`, `COVERAGE BY LAYER`).
- **Numbers & data:** always mono with tabular figures. Deltas read `↑ 12%` / `↓ 3.1%`. Currency abbreviated (`$1.24M`). Keep precision honest, not decorative.
- **Labels:** nouns for objects (*node, connection, layer, topic, canvas*), verbs for actions. A node has a *kind* (Source / Metric / Theme) and a *layer*.
- **Microcopy:** helpful, low-key, occasionally a single tip in a soft green well ("Drag from a node handle to draw a connection."). No exclamation marks, no hype.
- **Emoji:** none. Not part of the brand.
- **Examples:** "5 nodes · 4 connections" · "updated 2m ago" · "2 topics flagged" · "Sources feed Metrics feed Themes".

---

## VISUAL FOUNDATIONS
The look and feel, answered concretely.

- **Overall vibe:** clean and minimal — near-monochrome. White/ink paper in light mode, a deep muted-green dark mode, with a single restrained forest-green accent. Inspired by clean editorial/resume layouts: lots of whitespace, hairline rules, no decoration.
- **Color:**
  - *Neutrals* are clean, near-neutral paper: app bg `--paper-0 #FCFCFB`, panels `--paper-1 #F5F5F3`, sunken `--paper-2`, crisp white cards on top.
  - *Text* is near-black ink: headings `--ink-0 #1A1A18`, body `--ink-1`, muted `--ink-2`, faint `--ink-3`.
  - *One accent:* **forest green `--green-500 #3C5247`** carries everything that needs emphasis — primary actions, selection, links, active edges. Two further **muted neutrals-with-hue** quietly distinguish categories: **slate `#5B666F`** (secondary / info) and **stone `#8A7E6E`** (tertiary). Used sparingly; the default state is monochrome.
  - *Semantic* tones are muted: success `#4F7A5C`, warning `#B0822F`, danger `#A24B3F`.
- **Type:** **Manrope** — one clean geometric sans for everything (display, UI, body), used at different weights/sizes rather than mixing families. **IBM Plex Mono** for data, tables and stats. **No serif** — simplicity over contrast. Display = Manrope semibold, large, with tight (-0.02em) tracking.
- **Spacing:** 4px base rhythm (`--space-*`). Generous whitespace; dense only where data lives (tables, toolbars).
- **Backgrounds:** the signature is a **faint fine line grid** (1px lines every 24px in `--canvas-grid`, light gray, defaulted to ~30% opacity so it's barely there) — *not* dots, gradients, or imagery. Surfaces are flat fills. No photographic backgrounds; the only gradient is a subtle protection gradient at the bottom of presentation mode.
- **Cards / nodes:** white surface, **8px** radius (`--radius-md`), 1px hairline border, very light shadow. Nodes add a **3px accent rail** on top (green/slate/stone) and four connection handles that **fade in on hover/select**. Selected = 1.5px green border + slightly raised shadow.
- **Connections:** smooth **bezier** curves, 1.75px, rounded caps, soft arrowhead; turn green and thicken slightly when active or when an endpoint is selected. Optional mid-line pill label. A `deloris-dash` marching-ants flow is available for "live" edges.
- **Corners:** xs 3 (chips) · sm 5 (controls) · md 8 (cards/nodes) · lg 12 · pill. Crisp and clean, never fully circular except avatars/handles.
- **Shadows:** neutral and very light — `--shadow-sm/md/lg/pop`, plus `--shadow-node` / `--shadow-node-drag`. The system leans on **hairline borders, not elevation**. No hard or colored glows.
- **Borders:** 1px `--line` (hairline gray) by default; `--line-strong` for inputs; focus is a green border + soft green ring (`--focus-ring`), never a blue browser outline.
- **Animation:** **gentle fades & soft eases** — `--ease-out` (a calm settle, `cubic-bezier(0.16,1,0.3,1)`) for entrances/movement, `--ease-soft` for UI state. Durations 130–360ms. **No bounce.** Bars grow in with a small stagger; the segmented indicator slides; nodes lift-and-scale 1.02 on drag.
- **Hover states:** surfaces darken one paper step (`--bg-sunken`); primary buttons go one green step darker and pick up a small shadow; ghost controls fill with the sunken well. Never lighten.
- **Press states:** controls scale down slightly (~0.92–0.985) and settle — a soft physical press, no color flash.
- **Transparency & blur:** used sparingly. Layered-view planes use `color-mix` translucency to suggest depth; presentation overlay uses a low-opacity protection gradient. No frosted-glass everywhere.
- **Imagery vibe:** essentially none by default — the brand leans on type, grid, and a single green rather than photography. If imagery is added, keep it muted and desaturated.
- **Layout rules:** fixed sidebar (264px) + top bar (56px) + optional right inspector (300px); the canvas fills the rest. Floating toolbar is bottom-center; zoom at the toolbar's end. Presentation mode removes all fixed chrome.
- **Theming:** a single `[data-theme="presentation"]` scope flips the same tokens to a deep muted-green dark mode for showing to an audience.

---

## ICONOGRAPHY
- **System:** [**Lucide**](https://lucide.dev) — its calm, even 2px stroke and rounded joints match Deloris's friendly-but-functional tone. Loaded from CDN (`lucide@0.469.0` UMD); render `<i data-lucide="name"></i>` and call `lucide.createIcons()`.
- **Why Lucide:** consistent outline weight, large set, no fills — reads as quiet and technical without being cold. **Flagged substitution:** there was no icon set in the (empty) repo, so Lucide is the chosen default; swap if Deloris adopts its own set.
- **Usage:** outline icons only, currentColor inherits text color; size 14–17px inline in controls, paired with sentence-case labels. Common glyphs: `mouse-pointer-2`, `hand`, `spline`, `square-plus`, `layers`, `presentation`, `layout-grid`, `search`, `eye`/`eye-off`, `share-2`, `trash-2`, `message-circle`.
- **No emoji. No unicode-as-icon** except the tiny trend arrows (↑ ↓ →) and the × close glyph, which are intentional typographic marks.
- **Logo:** Deloris has no supplied logo, so the system ships a **typographic wordmark** — "Deloris" set in Manrope semibold beside a green rounded-square **D** monogram. This is type, not artwork; replace with a real logo when available.

---

## Tokens & fonts
- `styles.css` (root) — the single entry consumers link. `@import`s only.
- `tokens/colors.css` · `typography.css` · `spacing.css` · `elevation.css` · `motion.css`.
- **Font note (flagged):** fonts (**Manrope** + **IBM Plex Mono**) load from the **Google Fonts CDN** via `@import` in `typography.css` — no local `.woff2` binaries are shipped. If you need self-hosted/offline fonts, send the files and I'll add `@font-face` rules and bundle them.

---

## Index / manifest
**Foundations (Design System tab):** `guidelines/` — paper neutrals, ink text, accent scales, semantic status, type families, type scale, mono & data, spacing scale, corner radii, elevation, motion easing, canvas surface.

**Components** (`window.DelorisDesignSystem_*` — see `check_design_system` for the exact namespace):
- `components/core/` — Button, IconButton, Card, Badge, Tag, Input, Switch, Tabs, SegmentedControl
- `components/canvas/` — Node, Connection, Toolbar
- `components/data/` — StatCard, DataTable, MetricBars

**UI kits** (`ui_kits/`):
- `canvas/` — the canvas workspace (flat / layered / presentation), drag + connect + edit.
- `insights/` — the statistics dashboard (stat cards, trend, coverage, topics table) with presentation toggle.

**Other:** `SKILL.md` (portable skill manifest), `readme.md` (this file).

> Each component directory also has `<Name>.prompt.md` (what/when + usage) and a `*.card.html` specimen for the Design System tab.
