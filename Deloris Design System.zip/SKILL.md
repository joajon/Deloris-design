---
name: deloris-design
description: Use this skill to generate well-branded interfaces and assets for Deloris, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping. Deloris is a clean, minimal, near-monochrome system for HTML information-canvas apps — draggable nodes, drawn bezier connections, statistics, table views, plus layered (3D) and deep-green presentation view modes. One forest-green accent, Manrope + IBM Plex Mono, hairline borders.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick map
- `readme.md` — full design guide: content fundamentals, visual foundations, iconography, token & font notes, and an index of everything.
- `styles.css` — the single CSS entry point; `@import`s every token + font file. Link this one file.
- `tokens/` — colors, typography, spacing, elevation, motion (CSS custom properties; both base values and semantic aliases).
- `components/{core,canvas,data}/` — React primitives. Each has `<Name>.jsx`, `<Name>.d.ts`, `<Name>.prompt.md`, and a `*.card.html` specimen.
- `guidelines/` — foundation specimen cards.
- `ui_kits/{canvas,insights}/` — full-screen, interactive product recreations to copy from.

## Working notes
- Components are bundled and exposed on a `window.DelorisDesignSystem_*` namespace. In standalone HTML, link `styles.css`, load the compiled bundle, then read components off that global (the README and the `*.card.html` files show the exact pattern).
- Style with the CSS custom properties — never hard-code hexes. Sentence case for all copy; numbers in mono. Icons are Lucide via CDN.
- Honor the calm motion language (soft eases, no bounce) and the fine line-grid canvas. Use the `[data-theme="presentation"]` scope for "show to an audience" views.
