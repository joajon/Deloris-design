Smooth bezier connection between two canvas points. Renders a full-canvas SVG overlay (place one per edge, layered behind nodes). Needs the `deloris-dash` keyframe (in the canvas card / UI kit) for the `animated` flow.

```jsx
<Connection from={{x:340,y:120}} to={{x:560,y:240}} label="depends on" active />
<Connection from={a} to={b} animated dashed arrow={false} />
```
