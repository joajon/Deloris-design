export interface Point { x: number; y: number; }
export interface ConnectionProps {
  /** Start point in canvas space. */
  from: Point;
  /** End point in canvas space. */
  to: Point;
  /** Highlighted (clay) line. */
  active?: boolean;
  dashed?: boolean;
  /** Marching-ants flow animation. */
  animated?: boolean;
  /** Optional mid-line pill label. */
  label?: string;
  /** Arrowhead at the end. @default true */
  arrow?: boolean;
  onClick?: (e: React.MouseEvent) => void;
  style?: React.CSSProperties;
}

/**
 * Smooth bezier edge between two canvas points. Renders a full-canvas SVG
 * overlay; stack one per connection behind your nodes.
 */
export function Connection(props: ConnectionProps): JSX.Element;
