import React from "react";

const accentVar = { green: "var(--green-500)", slate: "var(--slate-500)", stone: "var(--stone-500)", neutral: "var(--ink-3)" };

/**
 * A node on the canvas — a draggable paper card with a top accent rail,
 * title, optional meta row, body, and connection handles.
 */
export function Node({
  title = "Untitled",
  kind,
  accent = "green",
  selected = false,
  dragging = false,
  showHandles = true,
  meta,
  children,
  onPointerDown,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const ac = accentVar[accent] || accentVar.green;
  const handle = (pos) => (
    <span
      style={{
        position: "absolute", width: 11, height: 11, borderRadius: "50%",
        background: "var(--surface-white)", border: `2px solid ${ac}`,
        opacity: hover || selected ? 1 : 0,
        transition: "opacity var(--dur-fast) var(--ease-soft)",
        ...pos,
      }}
    />
  );

  return (
    <div
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      onPointerDown={onPointerDown}
      style={{
        position: "relative",
        width: 220,
        background: "var(--canvas-node-bg)",
        border: selected ? `1.5px solid ${ac}` : "1px solid var(--border-default)",
        borderRadius: "var(--radius-md)",
        boxShadow: dragging ? "var(--shadow-node-drag)" : selected ? "var(--shadow-lg)" : "var(--shadow-node)",
        overflow: "hidden",
        transition: "box-shadow var(--dur-base) var(--ease-out), border-color var(--dur-fast) var(--ease-soft), transform var(--dur-base) var(--ease-out)",
        transform: dragging ? "scale(1.02)" : "none",
        cursor: "grab",
        userSelect: "none",
        ...style,
      }}
      {...rest}
    >
      <span style={{ display: "block", height: 3, background: ac }} />
      <div style={{ padding: "12px 14px 14px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8 }}>
          {kind ? (
            <span style={{ font: "var(--type-overline)", letterSpacing: "var(--tracking-wide)", textTransform: "uppercase", color: ac }}>{kind}</span>
          ) : <span />}
        </div>
        <div style={{ font: "var(--type-heading)", fontSize: "var(--text-base)", color: "var(--text-strong)", marginTop: kind ? 4 : 0 }}>{title}</div>
        {meta ? <div style={{ font: "var(--type-caption)", color: "var(--text-muted)", marginTop: 4 }}>{meta}</div> : null}
        {children ? <div style={{ marginTop: 10, font: "var(--type-body-sm)", color: "var(--text-body)" }}>{children}</div> : null}
      </div>
      {showHandles ? (
        <>
          {handle({ top: -6, left: "50%", marginLeft: -5.5 })}
          {handle({ bottom: -6, left: "50%", marginLeft: -5.5 })}
          {handle({ left: -6, top: "50%", marginTop: -5.5 })}
          {handle({ right: -6, top: "50%", marginTop: -5.5 })}
        </>
      ) : null}
    </div>
  );
}
