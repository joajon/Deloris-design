import React from "react";

export interface ToolbarProps {
  children?: React.ReactNode;
  /** @default "horizontal" */
  orientation?: "horizontal" | "vertical";
  style?: React.CSSProperties;
}

/**
 * Floating raised toolbar pill for the canvas. Fill with IconButtons and
 * Toolbar.Divider separators.
 */
export function Toolbar(props: ToolbarProps): JSX.Element;
