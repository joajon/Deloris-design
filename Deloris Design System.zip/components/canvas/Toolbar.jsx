import React from "react";

/**
 * Floating canvas toolbar — a raised paper pill that groups tool controls.
 * Compose IconButtons (and <Toolbar.Divider/>) as children.
 */
export function Toolbar({ children, orientation = "horizontal", style, ...rest }) {
  const horiz = orientation === "horizontal";
  return (
    <div
      style={{
        display: "inline-flex",
        flexDirection: horiz ? "row" : "column",
        alignItems: "center",
        gap: 3,
        padding: 5,
        background: "var(--surface-card)",
        border: "1px solid var(--border-default)",
        borderRadius: "var(--radius-md)",
        boxShadow: "var(--shadow-lg)",
        ...style,
      }}
      {...rest}
    >
      {children}
    </div>
  );
}

Toolbar.Divider = function Divider({ orientation = "horizontal" }) {
  const horiz = orientation === "horizontal";
  return (
    <span
      style={{
        background: "var(--border-default)",
        width: horiz ? 1 : 20,
        height: horiz ? 20 : 1,
        margin: horiz ? "0 3px" : "3px 0",
        flex: "none",
      }}
    />
  );
};
