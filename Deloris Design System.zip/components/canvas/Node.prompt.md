Draggable canvas node — paper card with a colored top rail, kind label, title, meta line, body, and four connection handles (fade in on hover/select).

```jsx
<Node title="Q3 Revenue" kind="Metric" accent="slate" meta="updated 2m ago"
      selected style={{ position: "absolute", left: 120, top: 80 }}>
  $1.24M — up 12%
</Node>
```

Accents: green / slate / stone / neutral. Position with absolute `left`/`top`; set `dragging` for the lift-and-scale state.
