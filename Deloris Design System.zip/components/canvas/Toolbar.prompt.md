Floating raised toolbar pill for the canvas — group tool IconButtons with `Toolbar.Divider`.

```jsx
<Toolbar>
  <IconButton active label="Select"><i data-lucide="mouse-pointer-2"></i></IconButton>
  <IconButton label="Pan"><i data-lucide="hand"></i></IconButton>
  <Toolbar.Divider />
  <IconButton label="Add node"><i data-lucide="square-plus"></i></IconButton>
  <IconButton label="Connect"><i data-lucide="spline"></i></IconButton>
</Toolbar>
```

`orientation`: horizontal (default) / vertical.
