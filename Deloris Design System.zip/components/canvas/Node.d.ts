import React from "react";

export interface NodeProps {
  title?: string;
  /** Small uppercase category label above the title. */
  kind?: string;
  /** Accent rail + handle color. @default "green" */
  accent?: "green" | "slate" | "stone" | "neutral";
  selected?: boolean;
  dragging?: boolean;
  /** Show the four connection handles on hover/select. @default true */
  showHandles?: boolean;
  /** Caption line under the title. */
  meta?: React.ReactNode;
  children?: React.ReactNode;
  onPointerDown?: (e: React.PointerEvent) => void;
  style?: React.CSSProperties;
}

/**
 * A draggable canvas node — paper card with accent rail, title, meta, body
 * and four connection handles. Position it via absolute style left/top.
 *
 * @startingPoint section="Canvas" subtitle="Draggable canvas node card" viewport="700x220"
 */
export function Node(props: NodeProps): JSX.Element;
