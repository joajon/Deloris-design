import React from "react";

/**
 * A smooth bezier connection between two canvas points. Renders a full-canvas
 * absolutely-positioned SVG overlay (pointer-events pass through except the line).
 * Coordinates are in canvas space.
 */
export function Connection({
  from = { x: 0, y: 0 },
  to = { x: 100, y: 100 },
  active = false,
  dashed = false,
  animated = false,
  label,
  arrow = true,
  onClick,
  style,
}) {
  const dx = Math.max(40, Math.abs(to.x - from.x) * 0.5);
  const c1 = { x: from.x + dx, y: from.y };
  const c2 = { x: to.x - dx, y: to.y };
  const d = `M ${from.x} ${from.y} C ${c1.x} ${c1.y}, ${c2.x} ${c2.y}, ${to.x} ${to.y}`;
  const mid = { x: (from.x + to.x) / 2, y: (from.y + to.y) / 2 };
  const color = active ? "var(--canvas-edge-active)" : "var(--canvas-edge)";
  const uid = React.useId ? React.useId().replace(/:/g, "") : "edge" + Math.round(from.x + to.y);

  return (
    <svg
      style={{ position: "absolute", inset: 0, width: "100%", height: "100%", overflow: "visible", pointerEvents: "none", ...style }}
    >
      <defs>
        <marker id={`arw-${uid}`} viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
          <path d="M 0 0 L 10 5 L 0 10 z" fill={color} />
        </marker>
      </defs>
      {/* invisible fat hit-line */}
      <path d={d} fill="none" stroke="transparent" strokeWidth="14" style={{ pointerEvents: onClick ? "stroke" : "none", cursor: onClick ? "pointer" : "default" }} onClick={onClick} />
      <path
        d={d}
        fill="none"
        stroke={color}
        strokeWidth={active ? 2.25 : 1.75}
        strokeLinecap="round"
        strokeDasharray={dashed ? "5 6" : animated ? "6 8" : "none"}
        markerEnd={arrow ? `url(#arw-${uid})` : undefined}
        style={{
          transition: "stroke var(--dur-base) var(--ease-soft), stroke-width var(--dur-fast) var(--ease-soft)",
          animation: animated ? "deloris-dash 1.2s linear infinite" : "none",
        }}
      />
      {label ? (
        <g transform={`translate(${mid.x}, ${mid.y})`}>
          <rect x={-(String(label).length * 3.6 + 8)} y={-11} width={String(label).length * 7.2 + 16} height={22} rx={6}
                fill="var(--surface-card)" stroke="var(--border-default)" strokeWidth="1" />
          <text x={0} y={4} textAnchor="middle" style={{ font: "var(--type-caption)", fill: "var(--text-muted)" }}>{label}</text>
        </g>
      ) : null}
    </svg>
  );
}
