Text field with label, leading icon, clay focus ring, and hint/error states.

```jsx
<Input label="Node title" placeholder="Untitled" />
<Input label="Search" iconLeft={icon} hint="Filter by topic" />
<Input label="Weight" error="Must be a number" />
```
