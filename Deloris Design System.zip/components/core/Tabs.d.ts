import React from "react";

export interface TabItem { id: string; label: string; icon?: React.ReactNode; }
export interface TabsProps {
  items: TabItem[];
  value: string;
  onChange?: (id: string) => void;
  style?: React.CSSProperties;
}

/** Underline tab bar for switching panels or sections. */
export function Tabs(props: TabsProps): JSX.Element;
