import React from "react";

export interface BadgeProps {
  children?: React.ReactNode;
  /** @default "neutral" */
  tone?: "neutral" | "green" | "slate" | "stone" | "success" | "warning" | "danger";
  /** Leading status dot. */
  dot?: boolean;
  style?: React.CSSProperties;
}

/** Small uppercase status / category pill. */
export function Badge(props: BadgeProps): JSX.Element;
