Floating paper surface — the base container for nodes, panels, and content blocks.

```jsx
<Card elevation="md">…</Card>
<Card interactive selected onClick={select}>…</Card>
```

`elevation`: flat / sm / md / lg. `interactive` adds hover lift; `selected` shows the green border.
