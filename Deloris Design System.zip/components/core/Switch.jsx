import React from "react";

/**
 * Toggle switch. Use for binary view/state changes (e.g. Presentation mode).
 */
export function Switch({ checked = false, onChange, label, disabled = false, size = "md", style, ...rest }) {
  const w = size === "sm" ? 34 : 42;
  const h = size === "sm" ? 20 : 24;
  const knob = h - 6;
  return (
    <label style={{ display: "inline-flex", alignItems: "center", gap: 10, cursor: disabled ? "not-allowed" : "pointer", opacity: disabled ? 0.5 : 1, ...style }}>
      <span
        onClick={() => !disabled && onChange && onChange(!checked)}
        style={{
          position: "relative", width: w, height: h, flex: "none",
          background: checked ? "var(--accent)" : "var(--paper-3)",
          borderRadius: "var(--radius-pill)",
          transition: "background-color var(--dur-base) var(--ease-soft)",
        }}
        role="switch"
        aria-checked={checked}
        {...rest}
      >
        <span
          style={{
            position: "absolute", top: 3, left: checked ? w - knob - 3 : 3,
            width: knob, height: knob, borderRadius: "50%", background: "var(--surface-white)",
            boxShadow: "var(--shadow-sm)",
            transition: "left var(--dur-base) var(--ease-out)",
          }}
        />
      </span>
      {label ? <span style={{ font: "var(--type-body-sm)", color: "var(--text-body)" }}>{label}</span> : null}
    </label>
  );
}
