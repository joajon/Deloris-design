Rounded category tag — softer than Badge, for filters and node topics. Optional dot + remove control.

```jsx
<Tag tone="green" onRemove={drop}>Revenue</Tag>
<Tag selected onClick={toggle}>Operations</Tag>
```
