import React from "react";

/**
 * Removable / selectable category tag, softer & lower-case than Badge.
 */
export function Tag({ children, tone = "neutral", onRemove, selected = false, onClick, style, ...rest }) {
  const [hover, setHover] = React.useState(false);
  const accent = { neutral: "var(--ink-2)", green: "var(--green-600)", slate: "var(--slate-600)", stone: "var(--stone-600)" }[tone] || "var(--ink-2)";
  return (
    <span
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        padding: "4px 10px",
        background: selected ? "var(--accent-soft)" : "var(--bg-panel)",
        color: selected ? "var(--accent)" : "var(--text-body)",
        border: `1px solid ${selected ? "transparent" : "var(--border-default)"}`,
        borderRadius: "var(--radius-pill)",
        font: "var(--type-caption)",
        fontWeight: "var(--weight-medium)",
        cursor: onClick ? "pointer" : "default",
        transition: "var(--transition-control)",
        ...style,
      }}
      {...rest}
    >
      <span style={{ width: 7, height: 7, borderRadius: "50%", background: accent, flex: "none" }} />
      {children}
      {onRemove ? (
        <button
          type="button"
          onClick={(e) => { e.stopPropagation(); onRemove(e); }}
          style={{
            display: "inline-flex", alignItems: "center", justifyContent: "center",
            width: 16, height: 16, marginLeft: 1, marginRight: -3,
            border: "none", background: "transparent", borderRadius: "50%",
            color: "var(--text-faint)", cursor: "pointer", fontSize: 13, lineHeight: 1,
            transition: "var(--transition-control)",
          }}
          aria-label="Remove"
        >×</button>
      ) : null}
    </span>
  );
}
