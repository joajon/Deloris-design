Segmented control for picking one of a few options — the canonical view-mode switcher.

```jsx
<SegmentedControl value={view} onChange={setView} items={[
  { id: "flat", label: "Flat" },
  { id: "layered", label: "Layered" },
  { id: "present", label: "Presentation" },
]} />
```
