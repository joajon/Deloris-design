Icon-only square button for toolbars, node handles, and dense controls; always pass `label` for accessibility + tooltip.

```jsx
<IconButton label="Zoom in" onClick={zoom}><i data-lucide="plus"></i></IconButton>
<IconButton variant="solid" label="Connect"><i data-lucide="spline"></i></IconButton>
<IconButton active label="Pan tool"><i data-lucide="hand"></i></IconButton>
```

Variants: `ghost` (default), `outline`, `solid`. Use `active` for toggled tools.
