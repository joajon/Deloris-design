Small uppercase status pill for node states, categories, and counts.

```jsx
<Badge tone="success" dot>Synced</Badge>
<Badge tone="green">Source</Badge>
```

Tones: neutral, green, slate, stone, success, warning, danger. `dot` adds a leading status dot.
