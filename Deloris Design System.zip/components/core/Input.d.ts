import React from "react";

export interface InputProps {
  label?: string;
  value?: string;
  defaultValue?: string;
  placeholder?: string;
  iconLeft?: React.ReactNode;
  /** Helper text below the field. */
  hint?: string;
  /** Error message — turns the field danger-colored. */
  error?: string;
  /** @default "md" */
  size?: "sm" | "md" | "lg";
  disabled?: boolean;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  style?: React.CSSProperties;
}

/** Text input with label, leading icon, focus ring, and hint/error states. */
export function Input(props: InputProps): JSX.Element;
