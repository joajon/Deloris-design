import React from "react";

const sizes = {
  sm: { padding: "6px 12px", font: "var(--text-sm)", height: 30, gap: 6 },
  md: { padding: "8px 16px", font: "var(--text-base)", height: 38, gap: 8 },
  lg: { padding: "11px 22px", font: "var(--text-md)", height: 46, gap: 10 },
};

function variantStyle(variant) {
  switch (variant) {
    case "secondary":
      return { background: "var(--surface-card)", color: "var(--text-strong)", border: "1px solid var(--border-strong)" };
    case "ghost":
      return { background: "transparent", color: "var(--text-body)", border: "1px solid transparent" };
    case "danger":
      return { background: "var(--danger-500)", color: "var(--text-on-accent)", border: "1px solid var(--danger-500)" };
    case "primary":
    default:
      return { background: "var(--accent)", color: "var(--text-on-accent)", border: "1px solid var(--accent)" };
  }
}

/**
 * Deloris primary action button. Calm fills, soft hover, gentle press.
 */
export function Button({
  children,
  variant = "primary",
  size = "md",
  iconLeft,
  iconRight,
  disabled = false,
  fullWidth = false,
  onClick,
  style,
  ...rest
}) {
  const s = sizes[size] || sizes.md;
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  const base = variantStyle(variant);

  const hoverTint =
    variant === "primary" ? { background: "var(--accent-hover)", borderColor: "var(--accent-hover)" }
    : variant === "danger" ? { background: "var(--danger-700)", borderColor: "var(--danger-700)" }
    : variant === "secondary" ? { background: "var(--bg-sunken)" }
    : { background: "var(--bg-sunken)" };

  const css = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: s.gap,
    width: fullWidth ? "100%" : "auto",
    padding: s.padding,
    minHeight: s.height,
    font: "var(--type-label)",
    fontSize: s.font,
    fontWeight: "var(--weight-semibold)",
    borderRadius: "var(--radius-sm)",
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? 0.5 : 1,
    transition: "var(--transition-control), transform var(--dur-fast) var(--ease-soft)",
    transform: active && !disabled ? "translateY(0.5px) scale(0.985)" : "none",
    boxShadow: hover && !disabled && variant !== "ghost" ? "var(--shadow-sm)" : "none",
    whiteSpace: "nowrap",
    userSelect: "none",
    ...base,
    ...(hover && !disabled ? hoverTint : null),
    ...style,
  };

  return (
    <button
      type="button"
      disabled={disabled}
      onClick={disabled ? undefined : onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => { setHover(false); setActive(false); }}
      onMouseDown={() => setActive(true)}
      onMouseUp={() => setActive(false)}
      style={css}
      {...rest}
    >
      {iconLeft ? <span style={{ display: "inline-flex" }}>{iconLeft}</span> : null}
      {children}
      {iconRight ? <span style={{ display: "inline-flex" }}>{iconRight}</span> : null}
    </button>
  );
}
