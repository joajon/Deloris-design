import React from "react";

export interface TagProps {
  children?: React.ReactNode;
  /** Dot color. @default "neutral" */
  tone?: "neutral" | "green" | "slate" | "stone";
  /** Renders a × remove control. */
  onRemove?: (e: React.MouseEvent) => void;
  selected?: boolean;
  onClick?: (e: React.MouseEvent) => void;
  style?: React.CSSProperties;
}

/** Rounded, sentence-case category tag with optional dot + remove. */
export function Tag(props: TagProps): JSX.Element;
