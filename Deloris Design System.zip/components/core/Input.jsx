import React from "react";

/**
 * Text input with optional label, leading icon, and hint/error.
 */
export function Input({
  label,
  value,
  defaultValue,
  placeholder,
  iconLeft,
  hint,
  error,
  size = "md",
  disabled = false,
  onChange,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const pad = size === "sm" ? "6px 10px" : size === "lg" ? "12px 14px" : "9px 12px";
  const fs = size === "sm" ? "var(--text-sm)" : "var(--text-base)";
  const borderColor = error ? "var(--danger-500)" : focus ? "var(--border-focus)" : "var(--border-strong)";

  return (
    <label style={{ display: "flex", flexDirection: "column", gap: 6, ...style }}>
      {label ? (
        <span style={{ font: "var(--type-label)", color: "var(--text-body)" }}>{label}</span>
      ) : null}
      <span
        style={{
          display: "flex",
          alignItems: "center",
          gap: 8,
          background: disabled ? "var(--bg-sunken)" : "var(--surface-card)",
          border: `1px solid ${borderColor}`,
          borderRadius: "var(--radius-sm)",
          padding: pad,
          boxShadow: focus && !error ? "var(--focus-ring)" : "none",
          transition: "var(--transition-control)",
          opacity: disabled ? 0.6 : 1,
        }}
      >
        {iconLeft ? <span style={{ display: "inline-flex", color: "var(--text-faint)" }}>{iconLeft}</span> : null}
        <input
          value={value}
          defaultValue={defaultValue}
          placeholder={placeholder}
          disabled={disabled}
          onChange={onChange}
          onFocus={() => setFocus(true)}
          onBlur={() => setFocus(false)}
          style={{
            flex: 1, minWidth: 0, border: "none", outline: "none", background: "transparent",
            font: "var(--type-body)", fontSize: fs, color: "var(--text-strong)",
          }}
          {...rest}
        />
      </span>
      {error ? (
        <span style={{ font: "var(--type-caption)", color: "var(--danger-700)" }}>{error}</span>
      ) : hint ? (
        <span style={{ font: "var(--type-caption)", color: "var(--text-faint)" }}>{hint}</span>
      ) : null}
    </label>
  );
}
