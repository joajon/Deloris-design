import React from "react";

const tones = {
  neutral: { bg: "var(--bg-sunken)", fg: "var(--text-muted)", bd: "var(--border-default)" },
  green: { bg: "var(--green-50)", fg: "var(--green-700)", bd: "var(--green-100)" },
  slate: { bg: "var(--slate-50)", fg: "var(--slate-700)", bd: "var(--slate-100)" },
  stone: { bg: "var(--stone-50)", fg: "var(--stone-600)", bd: "var(--stone-100)" },
  success: { bg: "var(--success-50)", fg: "var(--success-700)", bd: "var(--success-50)" },
  warning: { bg: "var(--warning-50)", fg: "var(--warning-700)", bd: "var(--warning-50)" },
  danger: { bg: "var(--danger-50)", fg: "var(--danger-700)", bd: "var(--danger-50)" },
};

/**
 * Small status / category label.
 */
export function Badge({ children, tone = "neutral", dot = false, style, ...rest }) {
  const t = tones[tone] || tones.neutral;
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        padding: "3px 9px",
        background: t.bg,
        color: t.fg,
        border: `1px solid ${t.bd}`,
        borderRadius: "var(--radius-pill)",
        font: "var(--type-overline)",
        letterSpacing: "var(--tracking-wide)",
        textTransform: "uppercase",
        whiteSpace: "nowrap",
        ...style,
      }}
      {...rest}
    >
      {dot ? <span style={{ width: 6, height: 6, borderRadius: "50%", background: t.fg, opacity: 0.85 }} /> : null}
      {children}
    </span>
  );
}
