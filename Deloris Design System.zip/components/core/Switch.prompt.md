Binary toggle with optional label — for view/state switches like Presentation mode.

```jsx
<Switch checked={present} onChange={setPresent} label="Presentation view" />
```
