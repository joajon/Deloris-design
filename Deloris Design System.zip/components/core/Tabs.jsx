import React from "react";

/**
 * Underline tabs for switching panels/sections.
 * items: [{ id, label, icon? }]
 */
export function Tabs({ items = [], value, onChange, style }) {
  return (
    <div style={{ display: "flex", gap: 4, borderBottom: "1px solid var(--border-default)", ...style }}>
      {items.map((it) => {
        const active = it.id === value;
        return (
          <button
            key={it.id}
            type="button"
            onClick={() => onChange && onChange(it.id)}
            style={{
              position: "relative",
              display: "inline-flex", alignItems: "center", gap: 7,
              padding: "10px 12px 11px",
              border: "none", background: "transparent", cursor: "pointer",
              font: "var(--type-label)",
              color: active ? "var(--text-strong)" : "var(--text-muted)",
              transition: "color var(--dur-fast) var(--ease-soft)",
            }}
          >
            {it.icon ? <span style={{ display: "inline-flex" }}>{it.icon}</span> : null}
            {it.label}
            <span
              style={{
                position: "absolute", left: 8, right: 8, bottom: -1, height: 2,
                background: "var(--accent)", borderRadius: "2px 2px 0 0",
                opacity: active ? 1 : 0,
                transform: active ? "scaleX(1)" : "scaleX(0.4)",
                transition: "opacity var(--dur-base) var(--ease-soft), transform var(--dur-base) var(--ease-out)",
              }}
            />
          </button>
        );
      })}
    </div>
  );
}
