import React from "react";

export interface ButtonProps {
  children?: React.ReactNode;
  /** Visual emphasis. @default "primary" */
  variant?: "primary" | "secondary" | "ghost" | "danger";
  /** @default "md" */
  size?: "sm" | "md" | "lg";
  /** Icon element rendered before the label. */
  iconLeft?: React.ReactNode;
  /** Icon element rendered after the label. */
  iconRight?: React.ReactNode;
  disabled?: boolean;
  fullWidth?: boolean;
  onClick?: (e: React.MouseEvent) => void;
  style?: React.CSSProperties;
}

/**
 * Primary action control for Deloris. Clay-filled by default; secondary is a
 * bordered paper surface, ghost is chromeless for toolbars.
 *
 * @startingPoint section="Core" subtitle="Action button with variants & sizes" viewport="700x150"
 */
export function Button(props: ButtonProps): JSX.Element;
