import React from "react";

/**
 * Floating paper surface. The base container for nodes, panels, and content.
 */
export function Card({
  children,
  elevation = "md",
  padded = true,
  interactive = false,
  selected = false,
  style,
  onClick,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const shadow = { flat: "none", sm: "var(--shadow-sm)", md: "var(--shadow-md)", lg: "var(--shadow-lg)" }[elevation] || "var(--shadow-md)";

  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        background: "var(--surface-card)",
        border: selected ? "1.5px solid var(--accent)" : "1px solid var(--border-default)",
        borderRadius: "var(--radius-md)",
        boxShadow: selected ? "var(--shadow-lg)" : interactive && hover ? "var(--shadow-lg)" : shadow,
        padding: padded ? "var(--pad-card)" : 0,
        transition: "var(--transition-control), transform var(--dur-base) var(--ease-out)",
        transform: interactive && hover ? "translateY(-1px)" : "none",
        cursor: interactive ? "pointer" : "default",
        ...style,
      }}
      {...rest}
    >
      {children}
    </div>
  );
}
