Action button — green-filled primary, bordered secondary, chromeless ghost, and danger; use for the main commit action in a panel, dialog, or toolbar.

```jsx
<Button variant="primary" onClick={save}>Save canvas</Button>
<Button variant="secondary" size="sm" iconLeft={icon}>Add node</Button>
<Button variant="ghost">Cancel</Button>
```

Variants: `primary` (green), `secondary` (paper + border), `ghost` (transparent), `danger`. Sizes: `sm` / `md` / `lg`. Supports `iconLeft` / `iconRight`, `disabled`, `fullWidth`.
