import React from "react";

/**
 * Segmented control — pick one of a few options. Ideal for view modes
 * (Flat / Layered / Presentation). items: [{ id, label, icon? }]
 */
export function SegmentedControl({ items = [], value, onChange, size = "md", style }) {
  const pad = size === "sm" ? "5px 10px" : "7px 14px";
  const fs = size === "sm" ? "var(--text-xs)" : "var(--text-sm)";
  return (
    <div
      style={{
        display: "inline-flex", padding: 3, gap: 2,
        background: "var(--bg-sunken)",
        border: "1px solid var(--border-default)",
        borderRadius: "var(--radius-sm)",
        ...style,
      }}
    >
      {items.map((it) => {
        const active = it.id === value;
        return (
          <button
            key={it.id}
            type="button"
            onClick={() => onChange && onChange(it.id)}
            style={{
              display: "inline-flex", alignItems: "center", gap: 6,
              padding: pad, border: "none", cursor: "pointer",
              borderRadius: "var(--radius-xs)",
              background: active ? "var(--surface-card)" : "transparent",
              boxShadow: active ? "var(--shadow-sm)" : "none",
              color: active ? "var(--text-strong)" : "var(--text-muted)",
              font: "var(--type-label)", fontSize: fs,
              transition: "var(--transition-control)",
              whiteSpace: "nowrap",
            }}
          >
            {it.icon ? <span style={{ display: "inline-flex" }}>{it.icon}</span> : null}
            {it.label}
          </button>
        );
      })}
    </div>
  );
}
