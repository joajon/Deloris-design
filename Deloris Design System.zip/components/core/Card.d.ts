import React from "react";

export interface CardProps {
  children?: React.ReactNode;
  /** Shadow depth. @default "md" */
  elevation?: "flat" | "sm" | "md" | "lg";
  /** @default true */
  padded?: boolean;
  /** Adds hover lift + pointer. @default false */
  interactive?: boolean;
  /** Shows clay selection border. */
  selected?: boolean;
  style?: React.CSSProperties;
  onClick?: (e: React.MouseEvent) => void;
}

/**
 * Floating white paper surface — the base for nodes, panels and content blocks.
 *
 * @startingPoint section="Core" subtitle="Paper surface container" viewport="700x150"
 */
export function Card(props: CardProps): JSX.Element;
