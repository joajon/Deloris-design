import React from "react";

export interface SegItem { id: string; label: string; icon?: React.ReactNode; }
export interface SegmentedControlProps {
  items: SegItem[];
  value: string;
  onChange?: (id: string) => void;
  /** @default "md" */
  size?: "sm" | "md";
  style?: React.CSSProperties;
}

/**
 * Pick-one segmented control — the canonical Deloris view-mode switcher
 * (Flat / Layered / Presentation).
 *
 * @startingPoint section="Core" subtitle="View-mode segmented switcher" viewport="700x150"
 */
export function SegmentedControl(props: SegmentedControlProps): JSX.Element;
