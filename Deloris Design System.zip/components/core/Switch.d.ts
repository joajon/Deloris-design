import React from "react";

export interface SwitchProps {
  checked?: boolean;
  onChange?: (next: boolean) => void;
  label?: string;
  disabled?: boolean;
  /** @default "md" */
  size?: "sm" | "md";
  style?: React.CSSProperties;
}

/** Binary toggle for view/state changes (e.g. Presentation mode). */
export function Switch(props: SwitchProps): JSX.Element;
