Underline tab bar with a sliding clay indicator.

```jsx
<Tabs value={tab} onChange={setTab} items={[
  { id: "props", label: "Properties" },
  { id: "data", label: "Data" },
]} />
```
