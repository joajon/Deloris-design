import React from "react";

export interface IconButtonProps {
  children?: React.ReactNode;
  /** @default "md" */
  size?: "sm" | "md" | "lg";
  /** @default "ghost" */
  variant?: "ghost" | "outline" | "solid";
  /** Toggled/selected state — shows the soft clay well. */
  active?: boolean;
  disabled?: boolean;
  /** Accessible label + tooltip text (icon has no text). */
  label?: string;
  onClick?: (e: React.MouseEvent) => void;
  style?: React.CSSProperties;
}

/**
 * Square icon-only button for canvas toolbars, node handles, and dense controls.
 */
export function IconButton(props: IconButtonProps): JSX.Element;
