import React from "react";

const sizes = { sm: 30, md: 38, lg: 46 };

/**
 * Square icon-only button for toolbars and node controls.
 */
export function IconButton({
  children,
  size = "md",
  variant = "ghost",
  active = false,
  disabled = false,
  label,
  onClick,
  style,
  ...rest
}) {
  const dim = sizes[size] || sizes.md;
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);

  const base =
    variant === "solid"
      ? { background: "var(--accent)", color: "var(--text-on-accent)", border: "1px solid var(--accent)" }
      : variant === "outline"
      ? { background: "var(--surface-card)", color: "var(--text-body)", border: "1px solid var(--border-strong)" }
      : { background: "transparent", color: "var(--text-body)", border: "1px solid transparent" };

  const activeStyle = active
    ? { background: "var(--accent-soft)", color: "var(--accent)", borderColor: "transparent" }
    : null;
  const hoverStyle =
    hover && !disabled
      ? variant === "solid"
        ? { background: "var(--accent-hover)" }
        : { background: "var(--bg-sunken)", color: "var(--text-strong)" }
      : null;

  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      disabled={disabled}
      onClick={disabled ? undefined : onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => { setHover(false); setPress(false); }}
      onMouseDown={() => setPress(true)}
      onMouseUp={() => setPress(false)}
      style={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        width: dim,
        height: dim,
        borderRadius: "var(--radius-sm)",
        cursor: disabled ? "not-allowed" : "pointer",
        opacity: disabled ? 0.45 : 1,
        transition: "var(--transition-control), transform var(--dur-fast) var(--ease-soft)",
        transform: press && !disabled ? "scale(0.92)" : "none",
        ...base,
        ...activeStyle,
        ...hoverStyle,
        ...style,
      }}
      {...rest}
    >
      {children}
    </button>
  );
}
