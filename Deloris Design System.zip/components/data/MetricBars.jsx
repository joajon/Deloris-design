import React from "react";

const palette = ["var(--clay-500)", "var(--blue-500)", "var(--plum-500)", "var(--success-500)", "var(--warning-500)"];

/**
 * Minimal horizontal bar chart. data: [{ label, value, color? }]
 * Bars animate up to width on mount.
 */
export function MetricBars({ data = [], max, unit = "", style }) {
  const [mounted, setMounted] = React.useState(false);
  React.useEffect(() => {
    const t = requestAnimationFrame(() => setMounted(true));
    return () => cancelAnimationFrame(t);
  }, []);
  const peak = max ?? Math.max(1, ...data.map((d) => d.value));

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14, ...style }}>
      {data.map((d, i) => {
        const pct = Math.max(0, Math.min(100, (d.value / peak) * 100));
        return (
          <div key={d.label} style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
              <span style={{ font: "var(--type-body-sm)", color: "var(--text-body)" }}>{d.label}</span>
              <span style={{ font: "var(--type-mono)", color: "var(--text-strong)", fontVariantNumeric: "tabular-nums" }}>{d.value}{unit}</span>
            </div>
            <div style={{ height: 9, background: "var(--bg-sunken)", borderRadius: "var(--radius-pill)", overflow: "hidden" }}>
              <div
                style={{
                  height: "100%",
                  width: mounted ? `${pct}%` : "0%",
                  background: d.color || palette[i % palette.length],
                  borderRadius: "var(--radius-pill)",
                  transition: `width var(--dur-slower) var(--ease-out) ${i * 70}ms`,
                }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}
