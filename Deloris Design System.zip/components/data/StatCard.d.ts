import React from "react";

export interface StatCardProps {
  label: string;
  value: string | number;
  unit?: string;
  /** Delta text, e.g. "12%". */
  delta?: string | number;
  trend?: "up" | "down" | "flat";
  /** Left rail color. @default "green" */
  accent?: "green" | "slate" | "stone";
  footnote?: string;
  style?: React.CSSProperties;
}

/**
 * KPI stat card — mono value, uppercase label, and trend delta pill.
 *
 * @startingPoint section="Data" subtitle="KPI metric card with trend" viewport="700x150"
 */
export function StatCard(props: StatCardProps): JSX.Element;
