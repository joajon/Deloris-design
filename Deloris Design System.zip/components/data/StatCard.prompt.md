KPI stat card — big mono value, uppercase label, trend delta pill, left accent rail.

```jsx
<StatCard label="Active nodes" value="248" delta="12%" trend="up" />
<StatCard label="Revenue" value="$1.24M" accent="slate" delta="3%" trend="down" footnote="vs last quarter" />
```

`trend`: up (green) / down (red) / flat. `accent`: green / slate / stone.
