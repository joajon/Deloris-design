Calm, scannable data table — uppercase header, mono numeric columns, hover + green row selection.

```jsx
<DataTable
  columns={[
    { key: "name", label: "Topic" },
    { key: "nodes", label: "Nodes", align: "right", mono: true },
    { key: "status", label: "Status", render: (v) => <Badge tone="success">{v}</Badge> },
  ]}
  rows={data}
  onRowClick={open}
  selectedId={current}
/>
```

Use `mono` on numeric columns for tabular alignment; `render` for badges/custom cells.
