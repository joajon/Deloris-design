import React from "react";

/**
 * Calm, scannable data table. columns: [{ key, label, align?, mono?, render? }]
 * rows: array of objects keyed by column.key.
 */
export function DataTable({ columns = [], rows = [], selectable = false, selectedId, onRowClick, rowKey = "id", style }) {
  const [hoverRow, setHoverRow] = React.useState(null);
  return (
    <div style={{ border: "1px solid var(--border-default)", borderRadius: "var(--radius-md)", overflow: "hidden", background: "var(--surface-card)", ...style }}>
      <table style={{ width: "100%", borderCollapse: "collapse", font: "var(--type-body-sm)" }}>
        <thead>
          <tr style={{ background: "var(--bg-panel)" }}>
            {columns.map((c) => (
              <th
                key={c.key}
                style={{
                  textAlign: c.align || "left",
                  padding: "10px 16px",
                  font: "var(--type-overline)",
                  letterSpacing: "var(--tracking-wide)",
                  textTransform: "uppercase",
                  color: "var(--text-muted)",
                  borderBottom: "1px solid var(--border-default)",
                  whiteSpace: "nowrap",
                }}
              >
                {c.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => {
            const id = row[rowKey] ?? i;
            const isSel = selectable && id === selectedId;
            const isHover = hoverRow === id;
            return (
              <tr
                key={id}
                onMouseEnter={() => setHoverRow(id)}
                onMouseLeave={() => setHoverRow(null)}
                onClick={onRowClick ? () => onRowClick(row) : undefined}
                style={{
                  background: isSel ? "var(--accent-soft)" : isHover && onRowClick ? "var(--bg-panel)" : "transparent",
                  cursor: onRowClick ? "pointer" : "default",
                  transition: "background-color var(--dur-fast) var(--ease-soft)",
                  boxShadow: isSel ? "inset 2px 0 0 var(--accent)" : "none",
                }}
              >
                {columns.map((c) => (
                  <td
                    key={c.key}
                    style={{
                      textAlign: c.align || "left",
                      padding: "11px 16px",
                      borderBottom: i === rows.length - 1 ? "none" : "1px solid var(--border-subtle)",
                      color: "var(--text-body)",
                      fontFamily: c.mono ? "var(--font-mono)" : "var(--font-sans)",
                      fontVariantNumeric: c.mono ? "tabular-nums" : "normal",
                      whiteSpace: "nowrap",
                    }}
                  >
                    {c.render ? c.render(row[c.key], row) : row[c.key]}
                  </td>
                ))}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
