import React from "react";

export interface Column {
  key: string;
  label: string;
  align?: "left" | "right" | "center";
  /** Render this column in mono with tabular numbers. */
  mono?: boolean;
  /** Custom cell renderer. */
  render?: (value: any, row: any) => React.ReactNode;
}
export interface DataTableProps {
  columns: Column[];
  rows: any[];
  selectable?: boolean;
  selectedId?: string | number;
  onRowClick?: (row: any) => void;
  /** Field used as React key + selection id. @default "id" */
  rowKey?: string;
  style?: React.CSSProperties;
}

/**
 * Calm, scannable data table with mono numeric columns and row selection.
 *
 * @startingPoint section="Data" subtitle="Scannable data table" viewport="700x260"
 */
export function DataTable(props: DataTableProps): JSX.Element;
