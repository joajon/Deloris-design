import React from "react";

/**
 * KPI stat card — big mono value, label, and optional delta trend.
 */
export function StatCard({ label, value, unit, delta, trend, accent = "green", footnote, style, ...rest }) {
  const trendColor = trend === "up" ? "var(--success-700)" : trend === "down" ? "var(--danger-700)" : "var(--text-muted)";
  const trendBg = trend === "up" ? "var(--success-50)" : trend === "down" ? "var(--danger-50)" : "var(--bg-sunken)";
  const ac = { green: "var(--green-500)", slate: "var(--slate-500)", stone: "var(--stone-500)" }[accent] || "var(--green-500)";

  return (
    <div
      style={{
        position: "relative",
        background: "var(--surface-card)",
        border: "1px solid var(--border-default)",
        borderRadius: "var(--radius-md)",
        padding: "var(--space-5)",
        boxShadow: "var(--shadow-sm)",
        overflow: "hidden",
        ...style,
      }}
      {...rest}
    >
      <span style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: 3, background: ac }} />
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8 }}>
        <span style={{ font: "var(--type-overline)", letterSpacing: "var(--tracking-wide)", textTransform: "uppercase", color: "var(--text-muted)" }}>{label}</span>
        {delta != null ? (
          <span style={{ display: "inline-flex", alignItems: "center", gap: 4, padding: "2px 7px", borderRadius: "var(--radius-pill)", background: trendBg, color: trendColor, font: "var(--type-caption)", fontWeight: "var(--weight-semibold)" }}>
            {trend === "up" ? "↑" : trend === "down" ? "↓" : "→"} {delta}
          </span>
        ) : null}
      </div>
      <div style={{ display: "flex", alignItems: "baseline", gap: 5, marginTop: 10 }}>
        <span style={{ font: "var(--type-data)", color: "var(--text-strong)" }}>{value}</span>
        {unit ? <span style={{ font: "var(--type-mono)", color: "var(--text-muted)" }}>{unit}</span> : null}
      </div>
      {footnote ? <div style={{ font: "var(--type-caption)", color: "var(--text-faint)", marginTop: 6 }}>{footnote}</div> : null}
    </div>
  );
}
