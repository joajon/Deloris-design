Minimal horizontal bar chart — label + mono value, bars grow in with a soft staggered ease.

```jsx
<MetricBars unit="%" data={[
  { label: "Operations", value: 72 },
  { label: "Finance", value: 54, color: "var(--blue-500)" },
  { label: "Product", value: 38 },
]} />
```
