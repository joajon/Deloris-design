import React from "react";

export interface BarDatum { label: string; value: number; color?: string; }
export interface MetricBarsProps {
  data: BarDatum[];
  /** Scale ceiling; defaults to the max value. */
  max?: number;
  /** Appended to each value, e.g. "%". */
  unit?: string;
  style?: React.CSSProperties;
}

/** Minimal horizontal bar chart with staggered grow-in animation. */
export function MetricBars(props: MetricBarsProps): JSX.Element;
