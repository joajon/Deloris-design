/* @ds-bundle: {"format":3,"namespace":"DelorisDesignSystem_e3c294","components":[{"name":"Connection","sourcePath":"components/canvas/Connection.jsx"},{"name":"Node","sourcePath":"components/canvas/Node.jsx"},{"name":"Toolbar","sourcePath":"components/canvas/Toolbar.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Input","sourcePath":"components/core/Input.jsx"},{"name":"SegmentedControl","sourcePath":"components/core/SegmentedControl.jsx"},{"name":"Switch","sourcePath":"components/core/Switch.jsx"},{"name":"Tabs","sourcePath":"components/core/Tabs.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"DataTable","sourcePath":"components/data/DataTable.jsx"},{"name":"MetricBars","sourcePath":"components/data/MetricBars.jsx"},{"name":"StatCard","sourcePath":"components/data/StatCard.jsx"}],"sourceHashes":{"app.jsx":"0e1227bff29b","components/canvas/Connection.jsx":"fb15ffcae99d","components/canvas/Node.jsx":"d2a36b7590f3","components/canvas/Toolbar.jsx":"6cae0e1e9fa3","components/core/Badge.jsx":"88004e1a119a","components/core/Button.jsx":"7286b4b33f9f","components/core/Card.jsx":"a3385ea38acd","components/core/IconButton.jsx":"5c8dc2ca8b76","components/core/Input.jsx":"9dd966ad84fe","components/core/SegmentedControl.jsx":"030cbedb9b54","components/core/Switch.jsx":"444908f7cdb2","components/core/Tabs.jsx":"2a39f9498c7e","components/core/Tag.jsx":"149752baa64f","components/data/DataTable.jsx":"d2cda849eb93","components/data/MetricBars.jsx":"87480602eaaf","components/data/StatCard.jsx":"d5354883fd97","ui_kits/canvas/app.jsx":"30a194fd4db0","ui_kits/canvas/inspector.jsx":"d3f1ca356077","ui_kits/canvas/parts.jsx":"d6c4c9d09050","ui_kits/canvas/tweaks-panel.jsx":"6591467622ed","ui_kits/insights/app.jsx":"af47b34b4895"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.DelorisDesignSystem_e3c294 = window.DelorisDesignSystem_e3c294 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// app.jsx
try { (() => {
/* Deloris Canvas UI kit — stateful workspace app. */
const A = window.DelorisDesignSystem_e3c294;
const UI = {
  Icon: window.Icon,
  Sidebar: window.Sidebar,
  TopBar: window.TopBar,
  Inspector: window.Inspector,
  LayeredView: window.LayeredView
};
const NODE_W = 200;
const seedNodes = [{
  id: "n1",
  title: "Market data",
  kind: "Source",
  accent: "clay",
  x: 80,
  y: 90,
  layer: 0,
  value: ""
}, {
  id: "n2",
  title: "Customer signals",
  kind: "Source",
  accent: "clay",
  x: 80,
  y: 250,
  layer: 0,
  value: ""
}, {
  id: "n3",
  title: "Revenue forecast",
  kind: "Metric",
  accent: "blue",
  x: 400,
  y: 110,
  layer: 1,
  value: "$1.24M"
}, {
  id: "n4",
  title: "Churn rate",
  kind: "Metric",
  accent: "blue",
  x: 400,
  y: 280,
  layer: 1,
  value: "3.1%"
}, {
  id: "n5",
  title: "Growth thesis",
  kind: "Theme",
  accent: "plum",
  x: 720,
  y: 190,
  layer: 2,
  value: ""
}];
const seedEdges = [{
  from: "n1",
  to: "n3",
  label: "feeds",
  active: true
}, {
  from: "n2",
  to: "n4",
  label: "drives"
}, {
  from: "n3",
  to: "n5",
  label: "supports"
}, {
  from: "n4",
  to: "n5",
  label: "tempers"
}];
function CanvasFlat({
  nodes,
  edges,
  selected,
  onSelect,
  onDragNode,
  dragId,
  zoom,
  present
}) {
  const byId = Object.fromEntries(nodes.map(n => [n.id, n]));
  const anchor = (n, side) => ({
    x: n.x + (side === "out" ? NODE_W : 0),
    y: n.y + 42
  });
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      overflow: "hidden",
      background: "var(--canvas-bg)",
      backgroundImage: "linear-gradient(var(--canvas-grid) 1px,transparent 1px),linear-gradient(90deg,var(--canvas-grid) 1px,transparent 1px)",
      backgroundSize: "var(--canvas-grid-size) var(--canvas-grid-size)"
    },
    onPointerDown: e => {
      if (e.target === e.currentTarget) onSelect(null);
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: "100%",
      height: "100%",
      transform: `scale(${zoom})`,
      transformOrigin: "0 0",
      transition: "transform var(--dur-base) var(--ease-soft)"
    }
  }, edges.map((e, i) => {
    const a = byId[e.from],
      b = byId[e.to];
    if (!a || !b) return null;
    return /*#__PURE__*/React.createElement(A.Connection, {
      key: i,
      from: anchor(a, "out"),
      to: anchor(b, "in"),
      label: present ? undefined : e.label,
      active: e.active || a.id === selected || b.id === selected
    });
  }), nodes.map(n => /*#__PURE__*/React.createElement(A.Node, {
    key: n.id,
    title: n.title,
    kind: n.kind,
    accent: n.accent,
    meta: present ? undefined : null,
    selected: !present && n.id === selected,
    dragging: n.id === dragId,
    showHandles: !present,
    onPointerDown: e => {
      e.stopPropagation();
      onSelect(n.id);
      onDragNode(e, n.id);
    },
    style: {
      position: "absolute",
      left: n.x,
      top: n.y,
      width: NODE_W
    }
  }, n.value ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-data)",
      color: "var(--text-strong)",
      fontSize: "16px"
    }
  }, n.value) : null))));
}
function App() {
  const [nodes, setNodes] = React.useState(seedNodes);
  const [edges, setEdges] = React.useState(seedEdges);
  const [selected, setSelected] = React.useState("n3");
  const [view, setView] = React.useState("flat");
  const [layerVis, setLayerVis] = React.useState({
    0: true,
    1: true,
    2: true
  });
  const [zoom, setZoom] = React.useState(1);
  const [dragId, setDragId] = React.useState(null);
  const drag = React.useRef(null);
  React.useEffect(() => {
    if (window.lucide) window.lucide.createIcons();
  });
  const onDragNode = (e, id) => {
    const start = {
      px: e.clientX,
      py: e.clientY
    };
    const node = nodes.find(n => n.id === id);
    drag.current = {
      id,
      ...start,
      ox: node.x,
      oy: node.y
    };
    setDragId(id);
    const move = ev => {
      const d = drag.current;
      if (!d) return;
      const nx = d.ox + (ev.clientX - d.px) / zoom;
      const ny = d.oy + (ev.clientY - d.py) / zoom;
      setNodes(ns => ns.map(n => n.id === d.id ? {
        ...n,
        x: Math.max(0, nx),
        y: Math.max(0, ny)
      } : n));
    };
    const up = () => {
      drag.current = null;
      setDragId(null);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  };
  const updateNode = (id, patch) => setNodes(ns => ns.map(n => n.id === id ? {
    ...n,
    ...patch,
    layer: patch.accent ? {
      clay: 0,
      blue: 1,
      plum: 2,
      neutral: n.layer
    }[patch.accent] : n.layer
  } : n));
  const deleteNode = id => {
    setNodes(ns => ns.filter(n => n.id !== id));
    setEdges(es => es.filter(e => e.from !== id && e.to !== id));
    setSelected(null);
  };
  const addNode = () => {
    const id = "n" + Date.now();
    setNodes(ns => [...ns, {
      id,
      title: "New node",
      kind: "Source",
      accent: "clay",
      x: 120 + Math.random() * 120,
      y: 120 + Math.random() * 120,
      layer: 0,
      value: ""
    }]);
    setSelected(id);
  };
  const visibleNodes = nodes.filter(n => layerVis[n.layer]);
  const summary = {
    nodes: nodes.length,
    edges: edges.length,
    byLayer: window.LAYERS.map(l => ({
      label: l.name,
      value: nodes.filter(n => n.layer === l.id).length,
      color: l.color
    }))
  };
  const present = view === "present";
  const selNode = nodes.find(n => n.id === selected);
  return /*#__PURE__*/React.createElement("div", {
    "data-theme": present ? "presentation" : undefined,
    style: {
      display: "flex",
      height: "100vh",
      width: "100vw",
      background: "var(--bg-app)",
      fontFamily: "var(--font-sans)",
      overflow: "hidden",
      transition: "background-color var(--dur-slow) var(--ease-soft)"
    }
  }, !present && /*#__PURE__*/React.createElement(UI.Sidebar, {
    canvases: CANVASES,
    current: "c1",
    onSelect: () => {},
    layerVis: layerVis,
    onToggleLayer: id => setLayerVis(v => ({
      ...v,
      [id]: !v[id]
    }))
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: "flex",
      flexDirection: "column",
      minWidth: 0
    }
  }, !present && /*#__PURE__*/React.createElement(UI.TopBar, {
    title: "Strategy map",
    view: view,
    onView: setView,
    count: nodes.length
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      position: "relative"
    }
  }, view === "layered" ? /*#__PURE__*/React.createElement(UI.LayeredView, {
    nodes: visibleNodes,
    edges: edges,
    layerVis: layerVis
  }) : /*#__PURE__*/React.createElement(CanvasFlat, {
    nodes: visibleNodes,
    edges: edges,
    selected: selected,
    onSelect: setSelected,
    onDragNode: onDragNode,
    dragId: dragId,
    zoom: present ? 1.05 : zoom,
    present: present
  }), !present && view !== "layered" && /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: "50%",
      bottom: 20,
      transform: "translateX(-50%)"
    }
  }, /*#__PURE__*/React.createElement(A.Toolbar, null, /*#__PURE__*/React.createElement(A.IconButton, {
    active: true,
    label: "Select"
  }, /*#__PURE__*/React.createElement(UI.Icon, {
    n: "mouse-pointer-2"
  })), /*#__PURE__*/React.createElement(A.IconButton, {
    label: "Pan"
  }, /*#__PURE__*/React.createElement(UI.Icon, {
    n: "hand"
  })), /*#__PURE__*/React.createElement(A.Toolbar.Divider, null), /*#__PURE__*/React.createElement(A.IconButton, {
    label: "Add node",
    onClick: addNode
  }, /*#__PURE__*/React.createElement(UI.Icon, {
    n: "square-plus"
  })), /*#__PURE__*/React.createElement(A.IconButton, {
    label: "Connect"
  }, /*#__PURE__*/React.createElement(UI.Icon, {
    n: "spline"
  })), /*#__PURE__*/React.createElement(A.IconButton, {
    label: "Comment"
  }, /*#__PURE__*/React.createElement(UI.Icon, {
    n: "message-circle"
  })), /*#__PURE__*/React.createElement(A.Toolbar.Divider, null), /*#__PURE__*/React.createElement(A.IconButton, {
    label: "Zoom out",
    onClick: () => setZoom(z => Math.max(0.5, +(z - 0.1).toFixed(2)))
  }, /*#__PURE__*/React.createElement(UI.Icon, {
    n: "minus"
  })), /*#__PURE__*/React.createElement(A.IconButton, {
    label: "Zoom in",
    onClick: () => setZoom(z => Math.min(1.6, +(z + 0.1).toFixed(2)))
  }, /*#__PURE__*/React.createElement(UI.Icon, {
    n: "plus"
  })))), present && /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      right: 0,
      bottom: 0,
      padding: "20px 28px",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      background: "linear-gradient(to top, rgba(20,18,15,0.55), transparent)"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-serif)",
      fontSize: 26,
      fontWeight: 600,
      color: "var(--text-strong)"
    }
  }, "Strategy map"), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--type-caption)",
      color: "var(--text-muted)"
    }
  }, nodes.length, " nodes \xB7 ", edges.length, " connections")), /*#__PURE__*/React.createElement(A.Button, {
    variant: "secondary",
    size: "sm",
    iconLeft: /*#__PURE__*/React.createElement(UI.Icon, {
      n: "x",
      s: 15
    }),
    onClick: () => setView("flat")
  }, "Exit presentation")))), !present && /*#__PURE__*/React.createElement(UI.Inspector, {
    node: selNode,
    onChange: updateNode,
    onDelete: deleteNode,
    edges: edges,
    summary: summary
  }));
}
const CANVASES = [{
  id: "c1",
  name: "Strategy map",
  icon: "git-fork",
  count: 5
}, {
  id: "c2",
  name: "Q3 planning",
  icon: "calendar",
  count: 12
}, {
  id: "c3",
  name: "Risk model",
  icon: "shield-alert",
  count: 8
}, {
  id: "c4",
  name: "Org topics",
  icon: "network",
  count: 21
}];
ReactDOM.createRoot(document.getElementById("root")).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "app.jsx", error: String((e && e.message) || e) }); }

// components/canvas/Connection.jsx
try { (() => {
/**
 * A smooth bezier connection between two canvas points. Renders a full-canvas
 * absolutely-positioned SVG overlay (pointer-events pass through except the line).
 * Coordinates are in canvas space.
 */
function Connection({
  from = {
    x: 0,
    y: 0
  },
  to = {
    x: 100,
    y: 100
  },
  active = false,
  dashed = false,
  animated = false,
  label,
  arrow = true,
  onClick,
  style
}) {
  const dx = Math.max(40, Math.abs(to.x - from.x) * 0.5);
  const c1 = {
    x: from.x + dx,
    y: from.y
  };
  const c2 = {
    x: to.x - dx,
    y: to.y
  };
  const d = `M ${from.x} ${from.y} C ${c1.x} ${c1.y}, ${c2.x} ${c2.y}, ${to.x} ${to.y}`;
  const mid = {
    x: (from.x + to.x) / 2,
    y: (from.y + to.y) / 2
  };
  const color = active ? "var(--canvas-edge-active)" : "var(--canvas-edge)";
  const uid = React.useId ? React.useId().replace(/:/g, "") : "edge" + Math.round(from.x + to.y);
  return /*#__PURE__*/React.createElement("svg", {
    style: {
      position: "absolute",
      inset: 0,
      width: "100%",
      height: "100%",
      overflow: "visible",
      pointerEvents: "none",
      ...style
    }
  }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("marker", {
    id: `arw-${uid}`,
    viewBox: "0 0 10 10",
    refX: "8",
    refY: "5",
    markerWidth: "7",
    markerHeight: "7",
    orient: "auto-start-reverse"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 0 L 10 5 L 0 10 z",
    fill: color
  }))), /*#__PURE__*/React.createElement("path", {
    d: d,
    fill: "none",
    stroke: "transparent",
    strokeWidth: "14",
    style: {
      pointerEvents: onClick ? "stroke" : "none",
      cursor: onClick ? "pointer" : "default"
    },
    onClick: onClick
  }), /*#__PURE__*/React.createElement("path", {
    d: d,
    fill: "none",
    stroke: color,
    strokeWidth: active ? 2.25 : 1.75,
    strokeLinecap: "round",
    strokeDasharray: dashed ? "5 6" : animated ? "6 8" : "none",
    markerEnd: arrow ? `url(#arw-${uid})` : undefined,
    style: {
      transition: "stroke var(--dur-base) var(--ease-soft), stroke-width var(--dur-fast) var(--ease-soft)",
      animation: animated ? "deloris-dash 1.2s linear infinite" : "none"
    }
  }), label ? /*#__PURE__*/React.createElement("g", {
    transform: `translate(${mid.x}, ${mid.y})`
  }, /*#__PURE__*/React.createElement("rect", {
    x: -(String(label).length * 3.6 + 8),
    y: -11,
    width: String(label).length * 7.2 + 16,
    height: 22,
    rx: 6,
    fill: "var(--surface-card)",
    stroke: "var(--border-default)",
    strokeWidth: "1"
  }), /*#__PURE__*/React.createElement("text", {
    x: 0,
    y: 4,
    textAnchor: "middle",
    style: {
      font: "var(--type-caption)",
      fill: "var(--text-muted)"
    }
  }, label)) : null);
}
Object.assign(__ds_scope, { Connection });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/canvas/Connection.jsx", error: String((e && e.message) || e) }); }

// components/canvas/Node.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const accentVar = {
  green: "var(--green-500)",
  slate: "var(--slate-500)",
  stone: "var(--stone-500)",
  neutral: "var(--ink-3)"
};

/**
 * A node on the canvas — a draggable paper card with a top accent rail,
 * title, optional meta row, body, and connection handles.
 */
function Node({
  title = "Untitled",
  kind,
  accent = "green",
  selected = false,
  dragging = false,
  showHandles = true,
  meta,
  children,
  onPointerDown,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const ac = accentVar[accent] || accentVar.green;
  const handle = pos => /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      width: 11,
      height: 11,
      borderRadius: "50%",
      background: "var(--surface-white)",
      border: `2px solid ${ac}`,
      opacity: hover || selected ? 1 : 0,
      transition: "opacity var(--dur-fast) var(--ease-soft)",
      ...pos
    }
  });
  return /*#__PURE__*/React.createElement("div", _extends({
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    onPointerDown: onPointerDown,
    style: {
      position: "relative",
      width: 220,
      background: "var(--canvas-node-bg)",
      border: selected ? `1.5px solid ${ac}` : "1px solid var(--border-default)",
      borderRadius: "var(--radius-md)",
      boxShadow: dragging ? "var(--shadow-node-drag)" : selected ? "var(--shadow-lg)" : "var(--shadow-node)",
      overflow: "hidden",
      transition: "box-shadow var(--dur-base) var(--ease-out), border-color var(--dur-fast) var(--ease-soft), transform var(--dur-base) var(--ease-out)",
      transform: dragging ? "scale(1.02)" : "none",
      cursor: "grab",
      userSelect: "none",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      height: 3,
      background: ac
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "12px 14px 14px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 8
    }
  }, kind ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-overline)",
      letterSpacing: "var(--tracking-wide)",
      textTransform: "uppercase",
      color: ac
    }
  }, kind) : /*#__PURE__*/React.createElement("span", null)), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--type-heading)",
      fontSize: "var(--text-base)",
      color: "var(--text-strong)",
      marginTop: kind ? 4 : 0
    }
  }, title), meta ? /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--type-caption)",
      color: "var(--text-muted)",
      marginTop: 4
    }
  }, meta) : null, children ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 10,
      font: "var(--type-body-sm)",
      color: "var(--text-body)"
    }
  }, children) : null), showHandles ? /*#__PURE__*/React.createElement(React.Fragment, null, handle({
    top: -6,
    left: "50%",
    marginLeft: -5.5
  }), handle({
    bottom: -6,
    left: "50%",
    marginLeft: -5.5
  }), handle({
    left: -6,
    top: "50%",
    marginTop: -5.5
  }), handle({
    right: -6,
    top: "50%",
    marginTop: -5.5
  })) : null);
}
Object.assign(__ds_scope, { Node });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/canvas/Node.jsx", error: String((e && e.message) || e) }); }

// components/canvas/Toolbar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Floating canvas toolbar — a raised paper pill that groups tool controls.
 * Compose IconButtons (and <Toolbar.Divider/>) as children.
 */
function Toolbar({
  children,
  orientation = "horizontal",
  style,
  ...rest
}) {
  const horiz = orientation === "horizontal";
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "inline-flex",
      flexDirection: horiz ? "row" : "column",
      alignItems: "center",
      gap: 3,
      padding: 5,
      background: "var(--surface-card)",
      border: "1px solid var(--border-default)",
      borderRadius: "var(--radius-md)",
      boxShadow: "var(--shadow-lg)",
      ...style
    }
  }, rest), children);
}
Toolbar.Divider = function Divider({
  orientation = "horizontal"
}) {
  const horiz = orientation === "horizontal";
  return /*#__PURE__*/React.createElement("span", {
    style: {
      background: "var(--border-default)",
      width: horiz ? 1 : 20,
      height: horiz ? 20 : 1,
      margin: horiz ? "0 3px" : "3px 0",
      flex: "none"
    }
  });
};
Object.assign(__ds_scope, { Toolbar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/canvas/Toolbar.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const tones = {
  neutral: {
    bg: "var(--bg-sunken)",
    fg: "var(--text-muted)",
    bd: "var(--border-default)"
  },
  green: {
    bg: "var(--green-50)",
    fg: "var(--green-700)",
    bd: "var(--green-100)"
  },
  slate: {
    bg: "var(--slate-50)",
    fg: "var(--slate-700)",
    bd: "var(--slate-100)"
  },
  stone: {
    bg: "var(--stone-50)",
    fg: "var(--stone-600)",
    bd: "var(--stone-100)"
  },
  success: {
    bg: "var(--success-50)",
    fg: "var(--success-700)",
    bd: "var(--success-50)"
  },
  warning: {
    bg: "var(--warning-50)",
    fg: "var(--warning-700)",
    bd: "var(--warning-50)"
  },
  danger: {
    bg: "var(--danger-50)",
    fg: "var(--danger-700)",
    bd: "var(--danger-50)"
  }
};

/**
 * Small status / category label.
 */
function Badge({
  children,
  tone = "neutral",
  dot = false,
  style,
  ...rest
}) {
  const t = tones[tone] || tones.neutral;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      padding: "3px 9px",
      background: t.bg,
      color: t.fg,
      border: `1px solid ${t.bd}`,
      borderRadius: "var(--radius-pill)",
      font: "var(--type-overline)",
      letterSpacing: "var(--tracking-wide)",
      textTransform: "uppercase",
      whiteSpace: "nowrap",
      ...style
    }
  }, rest), dot ? /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: "50%",
      background: t.fg,
      opacity: 0.85
    }
  }) : null, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const sizes = {
  sm: {
    padding: "6px 12px",
    font: "var(--text-sm)",
    height: 30,
    gap: 6
  },
  md: {
    padding: "8px 16px",
    font: "var(--text-base)",
    height: 38,
    gap: 8
  },
  lg: {
    padding: "11px 22px",
    font: "var(--text-md)",
    height: 46,
    gap: 10
  }
};
function variantStyle(variant) {
  switch (variant) {
    case "secondary":
      return {
        background: "var(--surface-card)",
        color: "var(--text-strong)",
        border: "1px solid var(--border-strong)"
      };
    case "ghost":
      return {
        background: "transparent",
        color: "var(--text-body)",
        border: "1px solid transparent"
      };
    case "danger":
      return {
        background: "var(--danger-500)",
        color: "var(--text-on-accent)",
        border: "1px solid var(--danger-500)"
      };
    case "primary":
    default:
      return {
        background: "var(--accent)",
        color: "var(--text-on-accent)",
        border: "1px solid var(--accent)"
      };
  }
}

/**
 * Deloris primary action button. Calm fills, soft hover, gentle press.
 */
function Button({
  children,
  variant = "primary",
  size = "md",
  iconLeft,
  iconRight,
  disabled = false,
  fullWidth = false,
  onClick,
  style,
  ...rest
}) {
  const s = sizes[size] || sizes.md;
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  const base = variantStyle(variant);
  const hoverTint = variant === "primary" ? {
    background: "var(--accent-hover)",
    borderColor: "var(--accent-hover)"
  } : variant === "danger" ? {
    background: "var(--danger-700)",
    borderColor: "var(--danger-700)"
  } : variant === "secondary" ? {
    background: "var(--bg-sunken)"
  } : {
    background: "var(--bg-sunken)"
  };
  const css = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: s.gap,
    width: fullWidth ? "100%" : "auto",
    padding: s.padding,
    minHeight: s.height,
    font: "var(--type-label)",
    fontSize: s.font,
    fontWeight: "var(--weight-semibold)",
    borderRadius: "var(--radius-sm)",
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? 0.5 : 1,
    transition: "var(--transition-control), transform var(--dur-fast) var(--ease-soft)",
    transform: active && !disabled ? "translateY(0.5px) scale(0.985)" : "none",
    boxShadow: hover && !disabled && variant !== "ghost" ? "var(--shadow-sm)" : "none",
    whiteSpace: "nowrap",
    userSelect: "none",
    ...base,
    ...(hover && !disabled ? hoverTint : null),
    ...style
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    disabled: disabled,
    onClick: disabled ? undefined : onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setActive(false);
    },
    onMouseDown: () => setActive(true),
    onMouseUp: () => setActive(false),
    style: css
  }, rest), iconLeft ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex"
    }
  }, iconLeft) : null, children, iconRight ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex"
    }
  }, iconRight) : null);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Floating paper surface. The base container for nodes, panels, and content.
 */
function Card({
  children,
  elevation = "md",
  padded = true,
  interactive = false,
  selected = false,
  style,
  onClick,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const shadow = {
    flat: "none",
    sm: "var(--shadow-sm)",
    md: "var(--shadow-md)",
    lg: "var(--shadow-lg)"
  }[elevation] || "var(--shadow-md)";
  return /*#__PURE__*/React.createElement("div", _extends({
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      background: "var(--surface-card)",
      border: selected ? "1.5px solid var(--accent)" : "1px solid var(--border-default)",
      borderRadius: "var(--radius-md)",
      boxShadow: selected ? "var(--shadow-lg)" : interactive && hover ? "var(--shadow-lg)" : shadow,
      padding: padded ? "var(--pad-card)" : 0,
      transition: "var(--transition-control), transform var(--dur-base) var(--ease-out)",
      transform: interactive && hover ? "translateY(-1px)" : "none",
      cursor: interactive ? "pointer" : "default",
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const sizes = {
  sm: 30,
  md: 38,
  lg: 46
};

/**
 * Square icon-only button for toolbars and node controls.
 */
function IconButton({
  children,
  size = "md",
  variant = "ghost",
  active = false,
  disabled = false,
  label,
  onClick,
  style,
  ...rest
}) {
  const dim = sizes[size] || sizes.md;
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const base = variant === "solid" ? {
    background: "var(--accent)",
    color: "var(--text-on-accent)",
    border: "1px solid var(--accent)"
  } : variant === "outline" ? {
    background: "var(--surface-card)",
    color: "var(--text-body)",
    border: "1px solid var(--border-strong)"
  } : {
    background: "transparent",
    color: "var(--text-body)",
    border: "1px solid transparent"
  };
  const activeStyle = active ? {
    background: "var(--accent-soft)",
    color: "var(--accent)",
    borderColor: "transparent"
  } : null;
  const hoverStyle = hover && !disabled ? variant === "solid" ? {
    background: "var(--accent-hover)"
  } : {
    background: "var(--bg-sunken)",
    color: "var(--text-strong)"
  } : null;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": label,
    title: label,
    disabled: disabled,
    onClick: disabled ? undefined : onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setPress(false);
    },
    onMouseDown: () => setPress(true),
    onMouseUp: () => setPress(false),
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: dim,
      height: dim,
      borderRadius: "var(--radius-sm)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.45 : 1,
      transition: "var(--transition-control), transform var(--dur-fast) var(--ease-soft)",
      transform: press && !disabled ? "scale(0.92)" : "none",
      ...base,
      ...activeStyle,
      ...hoverStyle,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Text input with optional label, leading icon, and hint/error.
 */
function Input({
  label,
  value,
  defaultValue,
  placeholder,
  iconLeft,
  hint,
  error,
  size = "md",
  disabled = false,
  onChange,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const pad = size === "sm" ? "6px 10px" : size === "lg" ? "12px 14px" : "9px 12px";
  const fs = size === "sm" ? "var(--text-sm)" : "var(--text-base)";
  const borderColor = error ? "var(--danger-500)" : focus ? "var(--border-focus)" : "var(--border-strong)";
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6,
      ...style
    }
  }, label ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-label)",
      color: "var(--text-body)"
    }
  }, label) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      background: disabled ? "var(--bg-sunken)" : "var(--surface-card)",
      border: `1px solid ${borderColor}`,
      borderRadius: "var(--radius-sm)",
      padding: pad,
      boxShadow: focus && !error ? "var(--focus-ring)" : "none",
      transition: "var(--transition-control)",
      opacity: disabled ? 0.6 : 1
    }
  }, iconLeft ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      color: "var(--text-faint)"
    }
  }, iconLeft) : null, /*#__PURE__*/React.createElement("input", _extends({
    value: value,
    defaultValue: defaultValue,
    placeholder: placeholder,
    disabled: disabled,
    onChange: onChange,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      minWidth: 0,
      border: "none",
      outline: "none",
      background: "transparent",
      font: "var(--type-body)",
      fontSize: fs,
      color: "var(--text-strong)"
    }
  }, rest))), error ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-caption)",
      color: "var(--danger-700)"
    }
  }, error) : hint ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-caption)",
      color: "var(--text-faint)"
    }
  }, hint) : null);
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Input.jsx", error: String((e && e.message) || e) }); }

// components/core/SegmentedControl.jsx
try { (() => {
/**
 * Segmented control — pick one of a few options. Ideal for view modes
 * (Flat / Layered / Presentation). items: [{ id, label, icon? }]
 */
function SegmentedControl({
  items = [],
  value,
  onChange,
  size = "md",
  style
}) {
  const pad = size === "sm" ? "5px 10px" : "7px 14px";
  const fs = size === "sm" ? "var(--text-xs)" : "var(--text-sm)";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "inline-flex",
      padding: 3,
      gap: 2,
      background: "var(--bg-sunken)",
      border: "1px solid var(--border-default)",
      borderRadius: "var(--radius-sm)",
      ...style
    }
  }, items.map(it => {
    const active = it.id === value;
    return /*#__PURE__*/React.createElement("button", {
      key: it.id,
      type: "button",
      onClick: () => onChange && onChange(it.id),
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        padding: pad,
        border: "none",
        cursor: "pointer",
        borderRadius: "var(--radius-xs)",
        background: active ? "var(--surface-card)" : "transparent",
        boxShadow: active ? "var(--shadow-sm)" : "none",
        color: active ? "var(--text-strong)" : "var(--text-muted)",
        font: "var(--type-label)",
        fontSize: fs,
        transition: "var(--transition-control)",
        whiteSpace: "nowrap"
      }
    }, it.icon ? /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex"
      }
    }, it.icon) : null, it.label);
  }));
}
Object.assign(__ds_scope, { SegmentedControl });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/SegmentedControl.jsx", error: String((e && e.message) || e) }); }

// components/core/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Toggle switch. Use for binary view/state changes (e.g. Presentation mode).
 */
function Switch({
  checked = false,
  onChange,
  label,
  disabled = false,
  size = "md",
  style,
  ...rest
}) {
  const w = size === "sm" ? 34 : 42;
  const h = size === "sm" ? 20 : 24;
  const knob = h - 6;
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 10,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", _extends({
    onClick: () => !disabled && onChange && onChange(!checked),
    style: {
      position: "relative",
      width: w,
      height: h,
      flex: "none",
      background: checked ? "var(--accent)" : "var(--paper-3)",
      borderRadius: "var(--radius-pill)",
      transition: "background-color var(--dur-base) var(--ease-soft)"
    },
    role: "switch",
    "aria-checked": checked
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: 3,
      left: checked ? w - knob - 3 : 3,
      width: knob,
      height: knob,
      borderRadius: "50%",
      background: "var(--surface-white)",
      boxShadow: "var(--shadow-sm)",
      transition: "left var(--dur-base) var(--ease-out)"
    }
  })), label ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-body-sm)",
      color: "var(--text-body)"
    }
  }, label) : null);
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Switch.jsx", error: String((e && e.message) || e) }); }

// components/core/Tabs.jsx
try { (() => {
/**
 * Underline tabs for switching panels/sections.
 * items: [{ id, label, icon? }]
 */
function Tabs({
  items = [],
  value,
  onChange,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 4,
      borderBottom: "1px solid var(--border-default)",
      ...style
    }
  }, items.map(it => {
    const active = it.id === value;
    return /*#__PURE__*/React.createElement("button", {
      key: it.id,
      type: "button",
      onClick: () => onChange && onChange(it.id),
      style: {
        position: "relative",
        display: "inline-flex",
        alignItems: "center",
        gap: 7,
        padding: "10px 12px 11px",
        border: "none",
        background: "transparent",
        cursor: "pointer",
        font: "var(--type-label)",
        color: active ? "var(--text-strong)" : "var(--text-muted)",
        transition: "color var(--dur-fast) var(--ease-soft)"
      }
    }, it.icon ? /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex"
      }
    }, it.icon) : null, it.label, /*#__PURE__*/React.createElement("span", {
      style: {
        position: "absolute",
        left: 8,
        right: 8,
        bottom: -1,
        height: 2,
        background: "var(--accent)",
        borderRadius: "2px 2px 0 0",
        opacity: active ? 1 : 0,
        transform: active ? "scaleX(1)" : "scaleX(0.4)",
        transition: "opacity var(--dur-base) var(--ease-soft), transform var(--dur-base) var(--ease-out)"
      }
    }));
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Removable / selectable category tag, softer & lower-case than Badge.
 */
function Tag({
  children,
  tone = "neutral",
  onRemove,
  selected = false,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const accent = {
    neutral: "var(--ink-2)",
    green: "var(--green-600)",
    slate: "var(--slate-600)",
    stone: "var(--stone-600)"
  }[tone] || "var(--ink-2)";
  return /*#__PURE__*/React.createElement("span", _extends({
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      padding: "4px 10px",
      background: selected ? "var(--accent-soft)" : "var(--bg-panel)",
      color: selected ? "var(--accent)" : "var(--text-body)",
      border: `1px solid ${selected ? "transparent" : "var(--border-default)"}`,
      borderRadius: "var(--radius-pill)",
      font: "var(--type-caption)",
      fontWeight: "var(--weight-medium)",
      cursor: onClick ? "pointer" : "default",
      transition: "var(--transition-control)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: "50%",
      background: accent,
      flex: "none"
    }
  }), children, onRemove ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: e => {
      e.stopPropagation();
      onRemove(e);
    },
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: 16,
      height: 16,
      marginLeft: 1,
      marginRight: -3,
      border: "none",
      background: "transparent",
      borderRadius: "50%",
      color: "var(--text-faint)",
      cursor: "pointer",
      fontSize: 13,
      lineHeight: 1,
      transition: "var(--transition-control)"
    },
    "aria-label": "Remove"
  }, "\xD7") : null);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/data/DataTable.jsx
try { (() => {
/**
 * Calm, scannable data table. columns: [{ key, label, align?, mono?, render? }]
 * rows: array of objects keyed by column.key.
 */
function DataTable({
  columns = [],
  rows = [],
  selectable = false,
  selectedId,
  onRowClick,
  rowKey = "id",
  style
}) {
  const [hoverRow, setHoverRow] = React.useState(null);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      border: "1px solid var(--border-default)",
      borderRadius: "var(--radius-md)",
      overflow: "hidden",
      background: "var(--surface-card)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("table", {
    style: {
      width: "100%",
      borderCollapse: "collapse",
      font: "var(--type-body-sm)"
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
    style: {
      background: "var(--bg-panel)"
    }
  }, columns.map(c => /*#__PURE__*/React.createElement("th", {
    key: c.key,
    style: {
      textAlign: c.align || "left",
      padding: "10px 16px",
      font: "var(--type-overline)",
      letterSpacing: "var(--tracking-wide)",
      textTransform: "uppercase",
      color: "var(--text-muted)",
      borderBottom: "1px solid var(--border-default)",
      whiteSpace: "nowrap"
    }
  }, c.label)))), /*#__PURE__*/React.createElement("tbody", null, rows.map((row, i) => {
    const id = row[rowKey] ?? i;
    const isSel = selectable && id === selectedId;
    const isHover = hoverRow === id;
    return /*#__PURE__*/React.createElement("tr", {
      key: id,
      onMouseEnter: () => setHoverRow(id),
      onMouseLeave: () => setHoverRow(null),
      onClick: onRowClick ? () => onRowClick(row) : undefined,
      style: {
        background: isSel ? "var(--accent-soft)" : isHover && onRowClick ? "var(--bg-panel)" : "transparent",
        cursor: onRowClick ? "pointer" : "default",
        transition: "background-color var(--dur-fast) var(--ease-soft)",
        boxShadow: isSel ? "inset 2px 0 0 var(--accent)" : "none"
      }
    }, columns.map(c => /*#__PURE__*/React.createElement("td", {
      key: c.key,
      style: {
        textAlign: c.align || "left",
        padding: "11px 16px",
        borderBottom: i === rows.length - 1 ? "none" : "1px solid var(--border-subtle)",
        color: "var(--text-body)",
        fontFamily: c.mono ? "var(--font-mono)" : "var(--font-sans)",
        fontVariantNumeric: c.mono ? "tabular-nums" : "normal",
        whiteSpace: "nowrap"
      }
    }, c.render ? c.render(row[c.key], row) : row[c.key])));
  }))));
}
Object.assign(__ds_scope, { DataTable });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/DataTable.jsx", error: String((e && e.message) || e) }); }

// components/data/MetricBars.jsx
try { (() => {
const palette = ["var(--clay-500)", "var(--blue-500)", "var(--plum-500)", "var(--success-500)", "var(--warning-500)"];

/**
 * Minimal horizontal bar chart. data: [{ label, value, color? }]
 * Bars animate up to width on mount.
 */
function MetricBars({
  data = [],
  max,
  unit = "",
  style
}) {
  const [mounted, setMounted] = React.useState(false);
  React.useEffect(() => {
    const t = requestAnimationFrame(() => setMounted(true));
    return () => cancelAnimationFrame(t);
  }, []);
  const peak = max ?? Math.max(1, ...data.map(d => d.value));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14,
      ...style
    }
  }, data.map((d, i) => {
    const pct = Math.max(0, Math.min(100, d.value / peak * 100));
    return /*#__PURE__*/React.createElement("div", {
      key: d.label,
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "baseline"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        font: "var(--type-body-sm)",
        color: "var(--text-body)"
      }
    }, d.label), /*#__PURE__*/React.createElement("span", {
      style: {
        font: "var(--type-mono)",
        color: "var(--text-strong)",
        fontVariantNumeric: "tabular-nums"
      }
    }, d.value, unit)), /*#__PURE__*/React.createElement("div", {
      style: {
        height: 9,
        background: "var(--bg-sunken)",
        borderRadius: "var(--radius-pill)",
        overflow: "hidden"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        height: "100%",
        width: mounted ? `${pct}%` : "0%",
        background: d.color || palette[i % palette.length],
        borderRadius: "var(--radius-pill)",
        transition: `width var(--dur-slower) var(--ease-out) ${i * 70}ms`
      }
    })));
  }));
}
Object.assign(__ds_scope, { MetricBars });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/MetricBars.jsx", error: String((e && e.message) || e) }); }

// components/data/StatCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * KPI stat card — big mono value, label, and optional delta trend.
 */
function StatCard({
  label,
  value,
  unit,
  delta,
  trend,
  accent = "green",
  footnote,
  style,
  ...rest
}) {
  const trendColor = trend === "up" ? "var(--success-700)" : trend === "down" ? "var(--danger-700)" : "var(--text-muted)";
  const trendBg = trend === "up" ? "var(--success-50)" : trend === "down" ? "var(--danger-50)" : "var(--bg-sunken)";
  const ac = {
    green: "var(--green-500)",
    slate: "var(--slate-500)",
    stone: "var(--stone-500)"
  }[accent] || "var(--green-500)";
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      position: "relative",
      background: "var(--surface-card)",
      border: "1px solid var(--border-default)",
      borderRadius: "var(--radius-md)",
      padding: "var(--space-5)",
      boxShadow: "var(--shadow-sm)",
      overflow: "hidden",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      bottom: 0,
      width: 3,
      background: ac
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-overline)",
      letterSpacing: "var(--tracking-wide)",
      textTransform: "uppercase",
      color: "var(--text-muted)"
    }
  }, label), delta != null ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 4,
      padding: "2px 7px",
      borderRadius: "var(--radius-pill)",
      background: trendBg,
      color: trendColor,
      font: "var(--type-caption)",
      fontWeight: "var(--weight-semibold)"
    }
  }, trend === "up" ? "↑" : trend === "down" ? "↓" : "→", " ", delta) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      gap: 5,
      marginTop: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-data)",
      color: "var(--text-strong)"
    }
  }, value), unit ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-mono)",
      color: "var(--text-muted)"
    }
  }, unit) : null), footnote ? /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--type-caption)",
      color: "var(--text-faint)",
      marginTop: 6
    }
  }, footnote) : null);
}
Object.assign(__ds_scope, { StatCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/StatCard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/canvas/app.jsx
try { (() => {
/* Deloris Canvas UI kit — stateful workspace app. */
const A = window.DelorisDesignSystem_e3c294;
const UI = {
  Icon: window.Icon,
  Sidebar: window.Sidebar,
  TopBar: window.TopBar,
  Inspector: window.Inspector,
  LayeredView: window.LayeredView
};
const NODE_W = 200;
const seedNodes = [{
  id: "n1",
  title: "Market data",
  kind: "Source",
  accent: "green",
  x: 80,
  y: 90,
  layer: 0,
  value: ""
}, {
  id: "n2",
  title: "Customer signals",
  kind: "Source",
  accent: "green",
  x: 80,
  y: 250,
  layer: 0,
  value: ""
}, {
  id: "n3",
  title: "Revenue forecast",
  kind: "Metric",
  accent: "slate",
  x: 400,
  y: 110,
  layer: 1,
  value: "$1.24M"
}, {
  id: "n4",
  title: "Churn rate",
  kind: "Metric",
  accent: "slate",
  x: 400,
  y: 280,
  layer: 1,
  value: "3.1%"
}, {
  id: "n5",
  title: "Growth thesis",
  kind: "Theme",
  accent: "stone",
  x: 720,
  y: 190,
  layer: 2,
  value: ""
}];
const seedEdges = [{
  from: "n1",
  to: "n3",
  label: "feeds",
  active: true
}, {
  from: "n2",
  to: "n4",
  label: "drives"
}, {
  from: "n3",
  to: "n5",
  label: "supports"
}, {
  from: "n4",
  to: "n5",
  label: "tempers"
}];
function CanvasFlat({
  nodes,
  edges,
  selected,
  onSelect,
  onDragNode,
  dragId,
  zoom,
  present,
  gridOpacity = 0.3,
  gridSize = 24,
  showLabels = true
}) {
  const byId = Object.fromEntries(nodes.map(n => [n.id, n]));
  const anchor = (n, side) => ({
    x: n.x + (side === "out" ? NODE_W : 0),
    y: n.y + 42
  });
  const gridLine = `color-mix(in srgb, var(--canvas-grid) ${Math.round(gridOpacity * 100)}%, transparent)`;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      overflow: "hidden",
      background: "var(--canvas-bg)",
      backgroundImage: `linear-gradient(${gridLine} 1px,transparent 1px),linear-gradient(90deg,${gridLine} 1px,transparent 1px)`,
      backgroundSize: `${gridSize}px ${gridSize}px`
    },
    onPointerDown: e => {
      if (e.target === e.currentTarget) onSelect(null);
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: "100%",
      height: "100%",
      transform: `scale(${zoom})`,
      transformOrigin: "0 0",
      transition: "transform var(--dur-base) var(--ease-soft)"
    }
  }, edges.map((e, i) => {
    const a = byId[e.from],
      b = byId[e.to];
    if (!a || !b) return null;
    return /*#__PURE__*/React.createElement(A.Connection, {
      key: i,
      from: anchor(a, "out"),
      to: anchor(b, "in"),
      label: present || !showLabels ? undefined : e.label,
      active: e.active || a.id === selected || b.id === selected
    });
  }), nodes.map(n => /*#__PURE__*/React.createElement(A.Node, {
    key: n.id,
    title: n.title,
    kind: n.kind,
    accent: n.accent,
    meta: present ? undefined : null,
    selected: !present && n.id === selected,
    dragging: n.id === dragId,
    showHandles: !present,
    onPointerDown: e => {
      e.stopPropagation();
      onSelect(n.id);
      onDragNode(e, n.id);
    },
    style: {
      position: "absolute",
      left: n.x,
      top: n.y,
      width: NODE_W
    }
  }, n.value ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-data)",
      fontSize: 22,
      color: "var(--text-strong)"
    }
  }, n.value) : null))));
}
function App() {
  const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
    "gridOpacity": 0.3,
    "gridSize": 24,
    "showLabels": true
  } /*EDITMODE-END*/;
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [nodes, setNodes] = React.useState(seedNodes);
  const [edges, setEdges] = React.useState(seedEdges);
  const [selected, setSelected] = React.useState("n3");
  const [view, setView] = React.useState("flat");
  const [layerVis, setLayerVis] = React.useState({
    0: true,
    1: true,
    2: true
  });
  const [zoom, setZoom] = React.useState(1);
  const [dragId, setDragId] = React.useState(null);
  const drag = React.useRef(null);
  React.useEffect(() => {
    if (window.lucide) window.lucide.createIcons();
  });
  const onDragNode = (e, id) => {
    const start = {
      px: e.clientX,
      py: e.clientY
    };
    const node = nodes.find(n => n.id === id);
    drag.current = {
      id,
      ...start,
      ox: node.x,
      oy: node.y
    };
    setDragId(id);
    const move = ev => {
      const d = drag.current;
      if (!d) return;
      const nx = d.ox + (ev.clientX - d.px) / zoom;
      const ny = d.oy + (ev.clientY - d.py) / zoom;
      setNodes(ns => ns.map(n => n.id === d.id ? {
        ...n,
        x: Math.max(0, nx),
        y: Math.max(0, ny)
      } : n));
    };
    const up = () => {
      drag.current = null;
      setDragId(null);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  };
  const updateNode = (id, patch) => setNodes(ns => ns.map(n => n.id === id ? {
    ...n,
    ...patch,
    layer: patch.accent ? {
      green: 0,
      slate: 1,
      stone: 2,
      neutral: n.layer
    }[patch.accent] : n.layer
  } : n));
  const deleteNode = id => {
    setNodes(ns => ns.filter(n => n.id !== id));
    setEdges(es => es.filter(e => e.from !== id && e.to !== id));
    setSelected(null);
  };
  const addNode = () => {
    const id = "n" + Date.now();
    setNodes(ns => [...ns, {
      id,
      title: "New node",
      kind: "Source",
      accent: "green",
      x: 120 + Math.random() * 120,
      y: 120 + Math.random() * 120,
      layer: 0,
      value: ""
    }]);
    setSelected(id);
  };
  const visibleNodes = nodes.filter(n => layerVis[n.layer]);
  const summary = {
    nodes: nodes.length,
    edges: edges.length,
    byLayer: window.LAYERS.map(l => ({
      label: l.name,
      value: nodes.filter(n => n.layer === l.id).length,
      color: l.color
    }))
  };
  const present = view === "present";
  const selNode = nodes.find(n => n.id === selected);
  return /*#__PURE__*/React.createElement("div", {
    "data-theme": present ? "presentation" : undefined,
    style: {
      display: "flex",
      height: "100vh",
      width: "100vw",
      background: "var(--bg-app)",
      fontFamily: "var(--font-sans)",
      overflow: "hidden",
      transition: "background-color var(--dur-slow) var(--ease-soft)"
    }
  }, !present && /*#__PURE__*/React.createElement(UI.Sidebar, {
    canvases: CANVASES,
    current: "c1",
    onSelect: () => {},
    layerVis: layerVis,
    onToggleLayer: id => setLayerVis(v => ({
      ...v,
      [id]: !v[id]
    }))
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: "flex",
      flexDirection: "column",
      minWidth: 0
    }
  }, !present && /*#__PURE__*/React.createElement(UI.TopBar, {
    title: "Strategy map",
    view: view,
    onView: setView,
    count: nodes.length
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      position: "relative"
    }
  }, view === "layered" ? /*#__PURE__*/React.createElement(UI.LayeredView, {
    nodes: visibleNodes,
    edges: edges,
    layerVis: layerVis
  }) : /*#__PURE__*/React.createElement(CanvasFlat, {
    nodes: visibleNodes,
    edges: edges,
    selected: selected,
    onSelect: setSelected,
    onDragNode: onDragNode,
    dragId: dragId,
    zoom: present ? 1.05 : zoom,
    present: present,
    gridOpacity: t.gridOpacity,
    gridSize: t.gridSize,
    showLabels: t.showLabels
  }), !present && view !== "layered" && /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: "50%",
      bottom: 20,
      transform: "translateX(-50%)"
    }
  }, /*#__PURE__*/React.createElement(A.Toolbar, null, /*#__PURE__*/React.createElement(A.IconButton, {
    active: true,
    label: "Select"
  }, /*#__PURE__*/React.createElement(UI.Icon, {
    n: "mouse-pointer-2"
  })), /*#__PURE__*/React.createElement(A.IconButton, {
    label: "Pan"
  }, /*#__PURE__*/React.createElement(UI.Icon, {
    n: "hand"
  })), /*#__PURE__*/React.createElement(A.Toolbar.Divider, null), /*#__PURE__*/React.createElement(A.IconButton, {
    label: "Add node",
    onClick: addNode
  }, /*#__PURE__*/React.createElement(UI.Icon, {
    n: "square-plus"
  })), /*#__PURE__*/React.createElement(A.IconButton, {
    label: "Connect"
  }, /*#__PURE__*/React.createElement(UI.Icon, {
    n: "spline"
  })), /*#__PURE__*/React.createElement(A.IconButton, {
    label: "Comment"
  }, /*#__PURE__*/React.createElement(UI.Icon, {
    n: "message-circle"
  })), /*#__PURE__*/React.createElement(A.Toolbar.Divider, null), /*#__PURE__*/React.createElement(A.IconButton, {
    label: "Zoom out",
    onClick: () => setZoom(z => Math.max(0.5, +(z - 0.1).toFixed(2)))
  }, /*#__PURE__*/React.createElement(UI.Icon, {
    n: "minus"
  })), /*#__PURE__*/React.createElement(A.IconButton, {
    label: "Zoom in",
    onClick: () => setZoom(z => Math.min(1.6, +(z + 0.1).toFixed(2)))
  }, /*#__PURE__*/React.createElement(UI.Icon, {
    n: "plus"
  })))), present && /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      right: 0,
      bottom: 0,
      padding: "20px 28px",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      background: "linear-gradient(to top, rgba(20,18,15,0.55), transparent)"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 26,
      fontWeight: 600,
      color: "var(--text-strong)"
    }
  }, "Strategy map"), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--type-caption)",
      color: "var(--text-muted)"
    }
  }, nodes.length, " nodes \xB7 ", edges.length, " connections")), /*#__PURE__*/React.createElement(A.Button, {
    variant: "secondary",
    size: "sm",
    iconLeft: /*#__PURE__*/React.createElement(UI.Icon, {
      n: "x",
      s: 15
    }),
    onClick: () => setView("flat")
  }, "Exit presentation")))), !present && /*#__PURE__*/React.createElement(UI.Inspector, {
    node: selNode,
    onChange: updateNode,
    onDelete: deleteNode,
    edges: edges,
    summary: summary
  }), /*#__PURE__*/React.createElement(TweaksPanel, null, /*#__PURE__*/React.createElement(TweakSection, {
    label: "Canvas grid"
  }), /*#__PURE__*/React.createElement(TweakSlider, {
    label: "Grid opacity",
    value: t.gridOpacity,
    min: 0,
    max: 1,
    step: 0.05,
    onChange: v => setTweak('gridOpacity', v)
  }), /*#__PURE__*/React.createElement(TweakSlider, {
    label: "Grid spacing",
    value: t.gridSize,
    min: 12,
    max: 48,
    step: 4,
    unit: "px",
    onChange: v => setTweak('gridSize', v)
  }), /*#__PURE__*/React.createElement(TweakSection, {
    label: "Connections"
  }), /*#__PURE__*/React.createElement(TweakToggle, {
    label: "Show edge labels",
    value: t.showLabels,
    onChange: v => setTweak('showLabels', v)
  })));
}
const CANVASES = [{
  id: "c1",
  name: "Strategy map",
  icon: "git-fork",
  count: 5
}, {
  id: "c2",
  name: "Q3 planning",
  icon: "calendar",
  count: 12
}, {
  id: "c3",
  name: "Risk model",
  icon: "shield-alert",
  count: 8
}, {
  id: "c4",
  name: "Org topics",
  icon: "network",
  count: 21
}];
ReactDOM.createRoot(document.getElementById("root")).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/canvas/app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/canvas/inspector.jsx
try { (() => {
/* Deloris Canvas UI kit — right inspector + layered (3D) view. */
const _NS = window.DelorisDesignSystem_e3c294;
const _Icon = window.Icon;
function Inspector({
  node,
  onChange,
  onDelete,
  edges,
  summary
}) {
  if (!node) {
    return /*#__PURE__*/React.createElement("aside", {
      style: inspectorShell
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "18px 18px 14px",
        borderBottom: "1px solid var(--border-default)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        font: "var(--type-heading)",
        color: "var(--text-strong)"
      }
    }, "Overview"), /*#__PURE__*/React.createElement("div", {
      style: {
        font: "var(--type-caption)",
        color: "var(--text-muted)",
        marginTop: 2
      }
    }, "Select a node to edit it")), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 18,
        display: "flex",
        flexDirection: "column",
        gap: 12
      }
    }, /*#__PURE__*/React.createElement(_NS.StatCard, {
      label: "Nodes",
      value: summary.nodes,
      accent: "green"
    }), /*#__PURE__*/React.createElement(_NS.StatCard, {
      label: "Connections",
      value: summary.edges,
      accent: "slate"
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        background: "var(--bg-panel)",
        border: "1px solid var(--border-default)",
        borderRadius: "var(--radius-md)",
        padding: 14
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        font: "var(--type-overline)",
        letterSpacing: "var(--tracking-wide)",
        textTransform: "uppercase",
        color: "var(--text-faint)",
        marginBottom: 10
      }
    }, "Coverage by layer"), /*#__PURE__*/React.createElement(_NS.MetricBars, {
      unit: "",
      data: summary.byLayer
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        alignItems: "flex-start",
        padding: "10px 12px",
        background: "var(--accent-soft)",
        borderRadius: "var(--radius-sm)"
      }
    }, /*#__PURE__*/React.createElement(_Icon, {
      n: "lightbulb",
      s: 15,
      color: "var(--green-600)"
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        font: "var(--type-caption)",
        color: "var(--green-700)"
      }
    }, "Drag from a node handle to draw a connection. Switch to Layered to see relations by depth."))));
  }
  const accents = [["green", "var(--green-500)"], ["slate", "var(--slate-500)"], ["stone", "var(--stone-500)"], ["neutral", "var(--ink-3)"]];
  const related = edges.filter(e => e.from === node.id || e.to === node.id);
  return /*#__PURE__*/React.createElement("aside", {
    style: inspectorShell
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "16px 18px",
      borderBottom: "1px solid var(--border-default)",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement(_NS.Badge, {
    tone: node.accent === "neutral" ? "neutral" : node.accent
  }, node.kind), /*#__PURE__*/React.createElement(_NS.IconButton, {
    label: "Delete node",
    size: "sm",
    onClick: () => onDelete(node.id)
  }, /*#__PURE__*/React.createElement(_Icon, {
    n: "trash-2",
    s: 15
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 18,
      display: "flex",
      flexDirection: "column",
      gap: 16,
      overflowY: "auto"
    }
  }, /*#__PURE__*/React.createElement(_NS.Input, {
    label: "Title",
    value: node.title,
    onChange: e => onChange(node.id, {
      title: e.target.value
    })
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--type-label)",
      color: "var(--text-body)",
      marginBottom: 8
    }
  }, "Layer accent"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8
    }
  }, accents.map(([name, col]) => /*#__PURE__*/React.createElement("button", {
    key: name,
    onClick: () => onChange(node.id, {
      accent: name
    }),
    style: {
      width: 30,
      height: 30,
      borderRadius: "50%",
      background: col,
      cursor: "pointer",
      border: node.accent === name ? "2px solid var(--text-strong)" : "2px solid transparent",
      outline: node.accent === name ? "2px solid var(--surface-card)" : "none",
      outlineOffset: -4
    }
  })))), /*#__PURE__*/React.createElement(_NS.Input, {
    label: "Value",
    value: node.value || "",
    onChange: e => onChange(node.id, {
      value: e.target.value
    }),
    placeholder: "e.g. $1.24M"
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--type-label)",
      color: "var(--text-body)",
      marginBottom: 8
    }
  }, "Connections \xB7 ", related.length), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6
    }
  }, related.length === 0 ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-caption)",
      color: "var(--text-faint)"
    }
  }, "No connections yet") : related.map((e, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      padding: "8px 10px",
      background: "var(--bg-panel)",
      borderRadius: "var(--radius-sm)"
    }
  }, /*#__PURE__*/React.createElement(_Icon, {
    n: "spline",
    s: 14,
    color: "var(--text-faint)"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      font: "var(--type-caption)",
      color: "var(--text-body)"
    }
  }, e.label || "linked"), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-mono)",
      fontSize: 11,
      color: "var(--text-faint)"
    }
  }, e.from === node.id ? "out" : "in")))))));
}
const inspectorShell = {
  width: "var(--inspector-w)",
  flex: "none",
  background: "var(--bg-app)",
  borderLeft: "1px solid var(--border-default)",
  display: "flex",
  flexDirection: "column",
  height: "100%",
  boxSizing: "border-box"
};

/* ── Layered / 3D depth view ── stacked translucent planes by layer */
function LayeredView({
  nodes,
  edges,
  layerVis
}) {
  const planes = window.LAYERS;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      perspective: 1600,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      width: 560,
      height: 360,
      transformStyle: "preserve-3d",
      transform: "rotateX(50deg) rotateZ(-30deg)"
    }
  }, planes.map((p, i) => {
    if (!layerVis[p.id]) return null;
    const layerNodes = nodes.filter(n => n.layer === p.id);
    return /*#__PURE__*/React.createElement("div", {
      key: p.id,
      style: {
        position: "absolute",
        inset: 0,
        transform: `translateZ(${i * 90}px)`,
        background: "color-mix(in srgb, var(--surface-card) 86%, transparent)",
        border: `1.5px solid ${p.color}`,
        borderRadius: 16,
        boxShadow: "0 30px 50px rgba(58,52,45,0.16)",
        backgroundImage: "linear-gradient(var(--canvas-grid) 1px,transparent 1px),linear-gradient(90deg,var(--canvas-grid) 1px,transparent 1px)",
        backgroundSize: "28px 28px"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: "absolute",
        top: 10,
        left: 14,
        font: "var(--type-overline)",
        letterSpacing: "var(--tracking-wide)",
        textTransform: "uppercase",
        color: p.color
      }
    }, p.name), layerNodes.map(n => /*#__PURE__*/React.createElement("div", {
      key: n.id,
      style: {
        position: "absolute",
        left: n.x % 380 + 60,
        top: n.y % 220 + 50,
        padding: "7px 11px",
        background: "var(--surface-white)",
        border: `1px solid ${p.color}`,
        borderRadius: 8,
        boxShadow: "0 6px 14px rgba(58,52,45,0.18)",
        whiteSpace: "nowrap",
        font: "var(--type-label)",
        fontSize: 12,
        color: "var(--text-strong)"
      }
    }, n.title)));
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      bottom: 22,
      left: "50%",
      transform: "translateX(-50%)",
      font: "var(--type-caption)",
      color: "var(--text-muted)",
      background: "var(--surface-card)",
      border: "1px solid var(--border-default)",
      borderRadius: "var(--radius-pill)",
      padding: "6px 14px",
      boxShadow: "var(--shadow-sm)"
    }
  }, "Relations stacked by layer \u2014 Sources feed Metrics feed Themes"));
}
Object.assign(window, {
  Inspector,
  LayeredView
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/canvas/inspector.jsx", error: String((e && e.message) || e) }); }

// ui_kits/canvas/parts.jsx
try { (() => {
/* Deloris Canvas UI kit — presentational parts (Sidebar, TopBar, Inspector, LayeredView).
   Shares the design-system bundle via window.DelorisDesignSystem_e3c294.
   Exports to window for the sibling app.jsx (separate babel scope). */
const NS = window.DelorisDesignSystem_e3c294;
const Icon = ({
  n,
  s = 16,
  color
}) => /*#__PURE__*/React.createElement("i", {
  "data-lucide": n,
  style: {
    width: s,
    height: s,
    display: "inline-flex",
    color
  }
});
const LAYERS = [{
  id: 0,
  name: "Sources",
  accent: "green",
  color: "var(--green-500)"
}, {
  id: 1,
  name: "Metrics",
  accent: "slate",
  color: "var(--slate-500)"
}, {
  id: 2,
  name: "Themes",
  accent: "stone",
  color: "var(--stone-500)"
}];
function Wordmark({
  size = 22
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 9
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 26,
      height: 26,
      borderRadius: 7,
      background: "var(--green-500)",
      color: "#fff",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      fontFamily: "var(--font-display)",
      fontWeight: 600,
      fontSize: 17,
      boxShadow: "var(--shadow-sm)"
    }
  }, "D"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: size,
      fontWeight: 600,
      color: "var(--text-strong)",
      letterSpacing: "-0.01em"
    }
  }, "Deloris"));
}
function Sidebar({
  canvases,
  current,
  onSelect,
  layerVis,
  onToggleLayer
}) {
  return /*#__PURE__*/React.createElement("aside", {
    style: {
      width: "var(--sidebar-w)",
      flex: "none",
      background: "var(--bg-panel)",
      borderRight: "1px solid var(--border-default)",
      display: "flex",
      flexDirection: "column",
      height: "100%",
      boxSizing: "border-box"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "18px 18px 14px"
    }
  }, /*#__PURE__*/React.createElement(Wordmark, null)), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "0 14px 12px"
    }
  }, /*#__PURE__*/React.createElement(NS.Input, {
    iconLeft: /*#__PURE__*/React.createElement(Icon, {
      n: "search"
    }),
    placeholder: "Search canvas",
    size: "sm"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "6px 14px",
      overflowY: "auto",
      flex: 1
    }
  }, /*#__PURE__*/React.createElement(SideLabel, null, "Canvases"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 2,
      marginBottom: 18
    }
  }, canvases.map(c => /*#__PURE__*/React.createElement("button", {
    key: c.id,
    onClick: () => onSelect(c.id),
    style: {
      display: "flex",
      alignItems: "center",
      gap: 9,
      padding: "8px 10px",
      border: "none",
      borderRadius: "var(--radius-sm)",
      cursor: "pointer",
      textAlign: "left",
      width: "100%",
      background: c.id === current ? "var(--accent-soft)" : "transparent",
      color: c.id === current ? "var(--accent)" : "var(--text-body)",
      font: "var(--type-label)",
      transition: "var(--transition-control)"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    n: c.icon,
    s: 15
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, c.name), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-mono)",
      fontSize: 11,
      color: "var(--text-faint)"
    }
  }, c.count)))), /*#__PURE__*/React.createElement(SideLabel, null, "Layers"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 2
    }
  }, LAYERS.map(l => /*#__PURE__*/React.createElement("div", {
    key: l.id,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      padding: "8px 10px",
      borderRadius: "var(--radius-sm)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 9,
      height: 9,
      borderRadius: 3,
      background: l.color,
      flex: "none"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      font: "var(--type-label)",
      color: "var(--text-body)"
    }
  }, l.name), /*#__PURE__*/React.createElement("button", {
    onClick: () => onToggleLayer(l.id),
    style: {
      border: "none",
      background: "transparent",
      cursor: "pointer",
      color: "var(--text-faint)",
      display: "inline-flex",
      padding: 2
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    n: layerVis[l.id] ? "eye" : "eye-off",
    s: 15
  })))))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 14,
      borderTop: "1px solid var(--border-default)",
      display: "flex",
      alignItems: "center",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 30,
      height: 30,
      borderRadius: "50%",
      background: "var(--stone-300)",
      color: "#fff",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      font: "var(--type-label)"
    }
  }, "JJ"), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--type-label)",
      color: "var(--text-strong)"
    }
  }, "Jone J."), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--type-caption)",
      color: "var(--text-faint)"
    }
  }, "Workspace")), /*#__PURE__*/React.createElement(Icon, {
    n: "settings",
    s: 16,
    color: "var(--text-faint)"
  })));
}
const SideLabel = ({
  children
}) => /*#__PURE__*/React.createElement("div", {
  style: {
    font: "var(--type-overline)",
    letterSpacing: "var(--tracking-caps)",
    textTransform: "uppercase",
    color: "var(--text-faint)",
    padding: "0 10px 8px"
  }
}, children);
function TopBar({
  title,
  view,
  onView,
  count
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      height: "var(--toolbar-h)",
      flex: "none",
      display: "flex",
      alignItems: "center",
      gap: 16,
      padding: "0 18px",
      borderBottom: "1px solid var(--border-default)",
      background: "var(--bg-app)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-heading)",
      color: "var(--text-strong)",
      whiteSpace: "nowrap"
    }
  }, title), /*#__PURE__*/React.createElement(NS.Badge, {
    tone: "neutral"
  }, count, " nodes")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: "flex",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement(NS.SegmentedControl, {
    value: view,
    onChange: onView,
    items: [{
      id: "flat",
      label: "Flat",
      icon: /*#__PURE__*/React.createElement(Icon, {
        n: "layout-grid",
        s: 14
      })
    }, {
      id: "layered",
      label: "Layered",
      icon: /*#__PURE__*/React.createElement(Icon, {
        n: "layers",
        s: 14
      })
    }, {
      id: "present",
      label: "Present",
      icon: /*#__PURE__*/React.createElement(Icon, {
        n: "presentation",
        s: 14
      })
    }]
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(NS.IconButton, {
    label: "Comments"
  }, /*#__PURE__*/React.createElement(Icon, {
    n: "message-circle"
  })), /*#__PURE__*/React.createElement(NS.IconButton, {
    label: "History"
  }, /*#__PURE__*/React.createElement(Icon, {
    n: "history"
  })), /*#__PURE__*/React.createElement(NS.Button, {
    variant: "secondary",
    size: "sm",
    iconLeft: /*#__PURE__*/React.createElement(Icon, {
      n: "share-2",
      s: 15
    })
  }, "Share")));
}
Object.assign(window, {
  NS,
  Icon,
  LAYERS,
  Wordmark,
  Sidebar,
  TopBar,
  SideLabel
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/canvas/parts.jsx", error: String((e && e.message) || e) }); }

// ui_kits/canvas/tweaks-panel.jsx
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)

/* BEGIN USAGE */
// tweaks-panel.jsx
// Reusable Tweaks shell + form-control helpers.
// Exports (to window): useTweaks, TweaksPanel, TweakSection, TweakRow, TweakSlider,
//   TweakToggle, TweakRadio, TweakSelect, TweakText, TweakNumber, TweakColor, TweakButton.
//
// Owns the host protocol (listens for __activate_edit_mode / __deactivate_edit_mode,
// posts __edit_mode_available / __edit_mode_set_keys / __edit_mode_dismissed) so
// individual prototypes don't re-roll it. Ships a consistent set of controls so you
// don't hand-draw <input type="range">, segmented radios, steppers, etc.
//
// Usage (in an HTML file that loads React + Babel):
//
//   const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
//     "primaryColor": "#D97757",
//     "palette": ["#D97757", "#29261b", "#f6f4ef"],
//     "fontSize": 16,
//     "density": "regular",
//     "dark": false
//   }/*EDITMODE-END*/;
//
//   function App() {
//     const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
//     return (
//       <div style={{ fontSize: t.fontSize, color: t.primaryColor }}>
//         Hello
//         <TweaksPanel>
//           <TweakSection label="Typography" />
//           <TweakSlider label="Font size" value={t.fontSize} min={10} max={32} unit="px"
//                        onChange={(v) => setTweak('fontSize', v)} />
//           <TweakRadio  label="Density" value={t.density}
//                        options={['compact', 'regular', 'comfy']}
//                        onChange={(v) => setTweak('density', v)} />
//           <TweakSection label="Theme" />
//           <TweakColor  label="Primary" value={t.primaryColor}
//                        options={['#D97757', '#2A6FDB', '#1F8A5B', '#7A5AE0']}
//                        onChange={(v) => setTweak('primaryColor', v)} />
//           <TweakColor  label="Palette" value={t.palette}
//                        options={[['#D97757', '#29261b', '#f6f4ef'],
//                                  ['#475569', '#0f172a', '#f1f5f9']]}
//                        onChange={(v) => setTweak('palette', v)} />
//           <TweakToggle label="Dark mode" value={t.dark}
//                        onChange={(v) => setTweak('dark', v)} />
//         </TweaksPanel>
//       </div>
//     );
//   }
//
// TweakRadio is the segmented control for 2–3 short options (auto-falls-back to
// TweakSelect past ~16/~10 chars per label); reach for TweakSelect directly when
// options are many or long. For color tweaks always curate 3-4 options rather than
// a free picker; an option can also be a whole 2–5 color palette (the stored value
// is the array). The Tweak* controls are a floor, not a ceiling — build custom
// controls inside the panel if a tweak calls for UI they don't cover.
/* END USAGE */
// ─────────────────────────────────────────────────────────────────────────────

const __TWEAKS_STYLE = `
  .twk-panel{position:fixed;right:16px;bottom:16px;z-index:2147483646;width:280px;
    max-height:calc(100vh - 32px);display:flex;flex-direction:column;
    transform:scale(var(--dc-inv-zoom,1));transform-origin:bottom right;
    background:rgba(250,249,247,.78);color:#29261b;
    -webkit-backdrop-filter:blur(24px) saturate(160%);backdrop-filter:blur(24px) saturate(160%);
    border:.5px solid rgba(255,255,255,.6);border-radius:14px;
    box-shadow:0 1px 0 rgba(255,255,255,.5) inset,0 12px 40px rgba(0,0,0,.18);
    font:11.5px/1.4 ui-sans-serif,system-ui,-apple-system,sans-serif;overflow:hidden}
  .twk-hd{display:flex;align-items:center;justify-content:space-between;
    padding:10px 8px 10px 14px;cursor:move;user-select:none}
  .twk-hd b{font-size:12px;font-weight:600;letter-spacing:.01em}
  .twk-x{appearance:none;border:0;background:transparent;color:rgba(41,38,27,.55);
    width:22px;height:22px;border-radius:6px;cursor:default;font-size:13px;line-height:1}
  .twk-x:hover{background:rgba(0,0,0,.06);color:#29261b}
  .twk-body{padding:2px 14px 14px;display:flex;flex-direction:column;gap:10px;
    overflow-y:auto;overflow-x:hidden;min-height:0;
    scrollbar-width:thin;scrollbar-color:rgba(0,0,0,.15) transparent}
  .twk-body::-webkit-scrollbar{width:8px}
  .twk-body::-webkit-scrollbar-track{background:transparent;margin:2px}
  .twk-body::-webkit-scrollbar-thumb{background:rgba(0,0,0,.15);border-radius:4px;
    border:2px solid transparent;background-clip:content-box}
  .twk-body::-webkit-scrollbar-thumb:hover{background:rgba(0,0,0,.25);
    border:2px solid transparent;background-clip:content-box}
  .twk-row{display:flex;flex-direction:column;gap:5px}
  .twk-row-h{flex-direction:row;align-items:center;justify-content:space-between;gap:10px}
  .twk-lbl{display:flex;justify-content:space-between;align-items:baseline;
    color:rgba(41,38,27,.72)}
  .twk-lbl>span:first-child{font-weight:500}
  .twk-val{color:rgba(41,38,27,.5);font-variant-numeric:tabular-nums}

  .twk-sect{font-size:10px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;
    color:rgba(41,38,27,.45);padding:10px 0 0}
  .twk-sect:first-child{padding-top:0}

  .twk-field{appearance:none;box-sizing:border-box;width:100%;min-width:0;height:26px;padding:0 8px;
    border:.5px solid rgba(0,0,0,.1);border-radius:7px;
    background:rgba(255,255,255,.6);color:inherit;font:inherit;outline:none}
  .twk-field:focus{border-color:rgba(0,0,0,.25);background:rgba(255,255,255,.85)}
  select.twk-field{padding-right:22px;
    background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'><path fill='rgba(0,0,0,.5)' d='M0 0h10L5 6z'/></svg>");
    background-repeat:no-repeat;background-position:right 8px center}

  .twk-slider{appearance:none;-webkit-appearance:none;width:100%;height:4px;margin:6px 0;
    border-radius:999px;background:rgba(0,0,0,.12);outline:none}
  .twk-slider::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;
    width:14px;height:14px;border-radius:50%;background:#fff;
    border:.5px solid rgba(0,0,0,.12);box-shadow:0 1px 3px rgba(0,0,0,.2);cursor:default}
  .twk-slider::-moz-range-thumb{width:14px;height:14px;border-radius:50%;
    background:#fff;border:.5px solid rgba(0,0,0,.12);box-shadow:0 1px 3px rgba(0,0,0,.2);cursor:default}

  .twk-seg{position:relative;display:flex;padding:2px;border-radius:8px;
    background:rgba(0,0,0,.06);user-select:none}
  .twk-seg-thumb{position:absolute;top:2px;bottom:2px;border-radius:6px;
    background:rgba(255,255,255,.9);box-shadow:0 1px 2px rgba(0,0,0,.12);
    transition:left .15s cubic-bezier(.3,.7,.4,1),width .15s}
  .twk-seg.dragging .twk-seg-thumb{transition:none}
  .twk-seg button{appearance:none;position:relative;z-index:1;flex:1;border:0;
    background:transparent;color:inherit;font:inherit;font-weight:500;min-height:22px;
    border-radius:6px;cursor:default;padding:4px 6px;line-height:1.2;
    overflow-wrap:anywhere}

  .twk-toggle{position:relative;width:32px;height:18px;border:0;border-radius:999px;
    background:rgba(0,0,0,.15);transition:background .15s;cursor:default;padding:0}
  .twk-toggle[data-on="1"]{background:#34c759}
  .twk-toggle i{position:absolute;top:2px;left:2px;width:14px;height:14px;border-radius:50%;
    background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.25);transition:transform .15s}
  .twk-toggle[data-on="1"] i{transform:translateX(14px)}

  .twk-num{display:flex;align-items:center;box-sizing:border-box;min-width:0;height:26px;padding:0 0 0 8px;
    border:.5px solid rgba(0,0,0,.1);border-radius:7px;background:rgba(255,255,255,.6)}
  .twk-num-lbl{font-weight:500;color:rgba(41,38,27,.6);cursor:ew-resize;
    user-select:none;padding-right:8px}
  .twk-num input{flex:1;min-width:0;height:100%;border:0;background:transparent;
    font:inherit;font-variant-numeric:tabular-nums;text-align:right;padding:0 8px 0 0;
    outline:none;color:inherit;-moz-appearance:textfield}
  .twk-num input::-webkit-inner-spin-button,.twk-num input::-webkit-outer-spin-button{
    -webkit-appearance:none;margin:0}
  .twk-num-unit{padding-right:8px;color:rgba(41,38,27,.45)}

  .twk-btn{appearance:none;height:26px;padding:0 12px;border:0;border-radius:7px;
    background:rgba(0,0,0,.78);color:#fff;font:inherit;font-weight:500;cursor:default}
  .twk-btn:hover{background:rgba(0,0,0,.88)}
  .twk-btn.secondary{background:rgba(0,0,0,.06);color:inherit}
  .twk-btn.secondary:hover{background:rgba(0,0,0,.1)}

  .twk-swatch{appearance:none;-webkit-appearance:none;width:56px;height:22px;
    border:.5px solid rgba(0,0,0,.1);border-radius:6px;padding:0;cursor:default;
    background:transparent;flex-shrink:0}
  .twk-swatch::-webkit-color-swatch-wrapper{padding:0}
  .twk-swatch::-webkit-color-swatch{border:0;border-radius:5.5px}
  .twk-swatch::-moz-color-swatch{border:0;border-radius:5.5px}

  .twk-chips{display:flex;gap:6px}
  .twk-chip{position:relative;appearance:none;flex:1;min-width:0;height:46px;
    padding:0;border:0;border-radius:6px;overflow:hidden;cursor:default;
    box-shadow:0 0 0 .5px rgba(0,0,0,.12),0 1px 2px rgba(0,0,0,.06);
    transition:transform .12s cubic-bezier(.3,.7,.4,1),box-shadow .12s}
  .twk-chip:hover{transform:translateY(-1px);
    box-shadow:0 0 0 .5px rgba(0,0,0,.18),0 4px 10px rgba(0,0,0,.12)}
  .twk-chip[data-on="1"]{box-shadow:0 0 0 1.5px rgba(0,0,0,.85),
    0 2px 6px rgba(0,0,0,.15)}
  .twk-chip>span{position:absolute;top:0;bottom:0;right:0;width:34%;
    display:flex;flex-direction:column;box-shadow:-1px 0 0 rgba(0,0,0,.1)}
  .twk-chip>span>i{flex:1;box-shadow:0 -1px 0 rgba(0,0,0,.1)}
  .twk-chip>span>i:first-child{box-shadow:none}
  .twk-chip svg{position:absolute;top:6px;left:6px;width:13px;height:13px;
    filter:drop-shadow(0 1px 1px rgba(0,0,0,.3))}
`;

// ── useTweaks ───────────────────────────────────────────────────────────────
// Single source of truth for tweak values. setTweak persists via the host
// (__edit_mode_set_keys → host rewrites the EDITMODE block on disk).
function useTweaks(defaults) {
  const [values, setValues] = React.useState(defaults);
  // Accepts either setTweak('key', value) or setTweak({ key: value, ... }) so a
  // useState-style call doesn't write a "[object Object]" key into the persisted
  // JSON block.
  const setTweak = React.useCallback((keyOrEdits, val) => {
    const edits = typeof keyOrEdits === 'object' && keyOrEdits !== null ? keyOrEdits : {
      [keyOrEdits]: val
    };
    setValues(prev => ({
      ...prev,
      ...edits
    }));
    window.parent.postMessage({
      type: '__edit_mode_set_keys',
      edits
    }, '*');
    // Same-window signal so in-page listeners (deck-stage rail thumbnails)
    // can react — the parent message only reaches the host, not peers.
    window.dispatchEvent(new CustomEvent('tweakchange', {
      detail: edits
    }));
  }, []);
  return [values, setTweak];
}

// ── TweaksPanel ─────────────────────────────────────────────────────────────
// Floating shell. Registers the protocol listener BEFORE announcing
// availability — if the announce ran first, the host's activate could land
// before our handler exists and the toolbar toggle would silently no-op.
// The close button posts __edit_mode_dismissed so the host's toolbar toggle
// flips off in lockstep; the host echoes __deactivate_edit_mode back which
// is what actually hides the panel.
function TweaksPanel({
  title = 'Tweaks',
  children
}) {
  const [open, setOpen] = React.useState(false);
  const dragRef = React.useRef(null);
  const offsetRef = React.useRef({
    x: 16,
    y: 16
  });
  const PAD = 16;
  const clampToViewport = React.useCallback(() => {
    const panel = dragRef.current;
    if (!panel) return;
    const w = panel.offsetWidth,
      h = panel.offsetHeight;
    const maxRight = Math.max(PAD, window.innerWidth - w - PAD);
    const maxBottom = Math.max(PAD, window.innerHeight - h - PAD);
    offsetRef.current = {
      x: Math.min(maxRight, Math.max(PAD, offsetRef.current.x)),
      y: Math.min(maxBottom, Math.max(PAD, offsetRef.current.y))
    };
    panel.style.right = offsetRef.current.x + 'px';
    panel.style.bottom = offsetRef.current.y + 'px';
  }, []);
  React.useEffect(() => {
    if (!open) return;
    clampToViewport();
    if (typeof ResizeObserver === 'undefined') {
      window.addEventListener('resize', clampToViewport);
      return () => window.removeEventListener('resize', clampToViewport);
    }
    const ro = new ResizeObserver(clampToViewport);
    ro.observe(document.documentElement);
    return () => ro.disconnect();
  }, [open, clampToViewport]);
  React.useEffect(() => {
    const onMsg = e => {
      const t = e?.data?.type;
      if (t === '__activate_edit_mode') setOpen(true);else if (t === '__deactivate_edit_mode') setOpen(false);
    };
    window.addEventListener('message', onMsg);
    window.parent.postMessage({
      type: '__edit_mode_available'
    }, '*');
    return () => window.removeEventListener('message', onMsg);
  }, []);
  const dismiss = () => {
    setOpen(false);
    window.parent.postMessage({
      type: '__edit_mode_dismissed'
    }, '*');
  };
  const onDragStart = e => {
    const panel = dragRef.current;
    if (!panel) return;
    const r = panel.getBoundingClientRect();
    const sx = e.clientX,
      sy = e.clientY;
    const startRight = window.innerWidth - r.right;
    const startBottom = window.innerHeight - r.bottom;
    const move = ev => {
      offsetRef.current = {
        x: startRight - (ev.clientX - sx),
        y: startBottom - (ev.clientY - sy)
      };
      clampToViewport();
    };
    const up = () => {
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  };
  if (!open) return null;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("style", null, __TWEAKS_STYLE), /*#__PURE__*/React.createElement("div", {
    ref: dragRef,
    className: "twk-panel",
    "data-omelette-chrome": "",
    style: {
      right: offsetRef.current.x,
      bottom: offsetRef.current.y
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-hd",
    onMouseDown: onDragStart
  }, /*#__PURE__*/React.createElement("b", null, title), /*#__PURE__*/React.createElement("button", {
    className: "twk-x",
    "aria-label": "Close tweaks",
    onMouseDown: e => e.stopPropagation(),
    onClick: dismiss
  }, "\u2715")), /*#__PURE__*/React.createElement("div", {
    className: "twk-body"
  }, children)));
}

// ── Layout helpers ──────────────────────────────────────────────────────────

function TweakSection({
  label,
  children
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "twk-sect"
  }, label), children);
}
function TweakRow({
  label,
  value,
  children,
  inline = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: inline ? 'twk-row twk-row-h' : 'twk-row'
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-lbl"
  }, /*#__PURE__*/React.createElement("span", null, label), value != null && /*#__PURE__*/React.createElement("span", {
    className: "twk-val"
  }, value)), children);
}

// ── Controls ────────────────────────────────────────────────────────────────

function TweakSlider({
  label,
  value,
  min = 0,
  max = 100,
  step = 1,
  unit = '',
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label,
    value: `${value}${unit}`
  }, /*#__PURE__*/React.createElement("input", {
    type: "range",
    className: "twk-slider",
    min: min,
    max: max,
    step: step,
    value: value,
    onChange: e => onChange(Number(e.target.value))
  }));
}
function TweakToggle({
  label,
  value,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "twk-row twk-row-h"
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-lbl"
  }, /*#__PURE__*/React.createElement("span", null, label)), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "twk-toggle",
    "data-on": value ? '1' : '0',
    role: "switch",
    "aria-checked": !!value,
    onClick: () => onChange(!value)
  }, /*#__PURE__*/React.createElement("i", null)));
}
function TweakRadio({
  label,
  value,
  options,
  onChange
}) {
  const trackRef = React.useRef(null);
  const [dragging, setDragging] = React.useState(false);
  // The active value is read by pointer-move handlers attached for the lifetime
  // of a drag — ref it so a stale closure doesn't fire onChange for every move.
  const valueRef = React.useRef(value);
  valueRef.current = value;

  // Segments wrap mid-word once per-segment width runs out. The track is
  // ~248px (280 panel − 28 body pad − 4 seg pad), each button loses 12px
  // to its own padding, and 11.5px system-ui averages ~6.3px/char — so 2
  // options fit ~16 chars each, 3 fit ~10. Past that (or >3 options), fall
  // back to a dropdown rather than wrap.
  const labelLen = o => String(typeof o === 'object' ? o.label : o).length;
  const maxLen = options.reduce((m, o) => Math.max(m, labelLen(o)), 0);
  const fitsAsSegments = maxLen <= ({
    2: 16,
    3: 10
  }[options.length] ?? 0);
  if (!fitsAsSegments) {
    // <select> emits strings — map back to the original option value so the
    // fallback stays type-preserving (numbers, booleans) like the segment path.
    const resolve = s => {
      const m = options.find(o => String(typeof o === 'object' ? o.value : o) === s);
      return m === undefined ? s : typeof m === 'object' ? m.value : m;
    };
    return /*#__PURE__*/React.createElement(TweakSelect, {
      label: label,
      value: value,
      options: options,
      onChange: s => onChange(resolve(s))
    });
  }
  const opts = options.map(o => typeof o === 'object' ? o : {
    value: o,
    label: o
  });
  const idx = Math.max(0, opts.findIndex(o => o.value === value));
  const n = opts.length;
  const segAt = clientX => {
    const r = trackRef.current.getBoundingClientRect();
    const inner = r.width - 4;
    const i = Math.floor((clientX - r.left - 2) / inner * n);
    return opts[Math.max(0, Math.min(n - 1, i))].value;
  };
  const onPointerDown = e => {
    setDragging(true);
    const v0 = segAt(e.clientX);
    if (v0 !== valueRef.current) onChange(v0);
    const move = ev => {
      if (!trackRef.current) return;
      const v = segAt(ev.clientX);
      if (v !== valueRef.current) onChange(v);
    };
    const up = () => {
      setDragging(false);
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("div", {
    ref: trackRef,
    role: "radiogroup",
    onPointerDown: onPointerDown,
    className: dragging ? 'twk-seg dragging' : 'twk-seg'
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-seg-thumb",
    style: {
      left: `calc(2px + ${idx} * (100% - 4px) / ${n})`,
      width: `calc((100% - 4px) / ${n})`
    }
  }), opts.map(o => /*#__PURE__*/React.createElement("button", {
    key: o.value,
    type: "button",
    role: "radio",
    "aria-checked": o.value === value
  }, o.label))));
}
function TweakSelect({
  label,
  value,
  options,
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("select", {
    className: "twk-field",
    value: value,
    onChange: e => onChange(e.target.value)
  }, options.map(o => {
    const v = typeof o === 'object' ? o.value : o;
    const l = typeof o === 'object' ? o.label : o;
    return /*#__PURE__*/React.createElement("option", {
      key: v,
      value: v
    }, l);
  })));
}
function TweakText({
  label,
  value,
  placeholder,
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("input", {
    className: "twk-field",
    type: "text",
    value: value,
    placeholder: placeholder,
    onChange: e => onChange(e.target.value)
  }));
}
function TweakNumber({
  label,
  value,
  min,
  max,
  step = 1,
  unit = '',
  onChange
}) {
  const clamp = n => {
    if (min != null && n < min) return min;
    if (max != null && n > max) return max;
    return n;
  };
  const startRef = React.useRef({
    x: 0,
    val: 0
  });
  const onScrubStart = e => {
    e.preventDefault();
    startRef.current = {
      x: e.clientX,
      val: value
    };
    const decimals = (String(step).split('.')[1] || '').length;
    const move = ev => {
      const dx = ev.clientX - startRef.current.x;
      const raw = startRef.current.val + dx * step;
      const snapped = Math.round(raw / step) * step;
      onChange(clamp(Number(snapped.toFixed(decimals))));
    };
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "twk-num"
  }, /*#__PURE__*/React.createElement("span", {
    className: "twk-num-lbl",
    onPointerDown: onScrubStart
  }, label), /*#__PURE__*/React.createElement("input", {
    type: "number",
    value: value,
    min: min,
    max: max,
    step: step,
    onChange: e => onChange(clamp(Number(e.target.value)))
  }), unit && /*#__PURE__*/React.createElement("span", {
    className: "twk-num-unit"
  }, unit));
}

// Relative-luminance contrast pick — checkmarks drawn over a swatch need to
// read on both #111 and #fafafa without per-option configuration. Hex input
// only (#rgb / #rrggbb); named or rgb()/hsl() colors fall through to "light".
function __twkIsLight(hex) {
  const h = String(hex).replace('#', '');
  const x = h.length === 3 ? h.replace(/./g, c => c + c) : h.padEnd(6, '0');
  const n = parseInt(x.slice(0, 6), 16);
  if (Number.isNaN(n)) return true;
  const r = n >> 16 & 255,
    g = n >> 8 & 255,
    b = n & 255;
  return r * 299 + g * 587 + b * 114 > 148000;
}
const __TwkCheck = ({
  light
}) => /*#__PURE__*/React.createElement("svg", {
  viewBox: "0 0 14 14",
  "aria-hidden": "true"
}, /*#__PURE__*/React.createElement("path", {
  d: "M3 7.2 5.8 10 11 4.2",
  fill: "none",
  strokeWidth: "2.2",
  strokeLinecap: "round",
  strokeLinejoin: "round",
  stroke: light ? 'rgba(0,0,0,.78)' : '#fff'
}));

// TweakColor — curated color/palette picker. Each option is either a single
// hex string or an array of 1-5 hex strings; the card adapts — a lone color
// renders solid, a palette renders colors[0] as the hero (left ~2/3) with the
// rest stacked in a sharp column on the right. onChange emits the
// option in the shape it was passed (string stays string, array stays array).
// Without options it falls back to the native color input for back-compat.
function TweakColor({
  label,
  value,
  options,
  onChange
}) {
  if (!options || !options.length) {
    return /*#__PURE__*/React.createElement("div", {
      className: "twk-row twk-row-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "twk-lbl"
    }, /*#__PURE__*/React.createElement("span", null, label)), /*#__PURE__*/React.createElement("input", {
      type: "color",
      className: "twk-swatch",
      value: value,
      onChange: e => onChange(e.target.value)
    }));
  }
  // Native <input type=color> emits lowercase hex per the HTML spec, so
  // compare case-insensitively. String() guards JSON.stringify(undefined),
  // which returns the primitive undefined (no .toLowerCase).
  const key = o => String(JSON.stringify(o)).toLowerCase();
  const cur = key(value);
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-chips",
    role: "radiogroup"
  }, options.map((o, i) => {
    const colors = Array.isArray(o) ? o : [o];
    const [hero, ...rest] = colors;
    const sup = rest.slice(0, 4);
    const on = key(o) === cur;
    return /*#__PURE__*/React.createElement("button", {
      key: i,
      type: "button",
      className: "twk-chip",
      role: "radio",
      "aria-checked": on,
      "data-on": on ? '1' : '0',
      "aria-label": colors.join(', '),
      title: colors.join(' · '),
      style: {
        background: hero
      },
      onClick: () => onChange(o)
    }, sup.length > 0 && /*#__PURE__*/React.createElement("span", null, sup.map((c, j) => /*#__PURE__*/React.createElement("i", {
      key: j,
      style: {
        background: c
      }
    }))), on && /*#__PURE__*/React.createElement(__TwkCheck, {
      light: __twkIsLight(hero)
    }));
  })));
}
function TweakButton({
  label,
  onClick,
  secondary = false
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: secondary ? 'twk-btn secondary' : 'twk-btn',
    onClick: onClick
  }, label);
}
Object.assign(window, {
  useTweaks,
  TweaksPanel,
  TweakSection,
  TweakRow,
  TweakSlider,
  TweakToggle,
  TweakRadio,
  TweakSelect,
  TweakText,
  TweakNumber,
  TweakColor,
  TweakButton
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/canvas/tweaks-panel.jsx", error: String((e && e.message) || e) }); }

// ui_kits/insights/app.jsx
try { (() => {
/* Deloris Insights UI kit — stats dashboard + table over the canvas data. */
const D = window.DelorisDesignSystem_e3c294;
const Ic = ({
  n,
  s = 16,
  color
}) => /*#__PURE__*/React.createElement("i", {
  "data-lucide": n,
  style: {
    width: s,
    height: s,
    display: "inline-flex",
    color
  }
});
const TOPICS = [{
  id: 1,
  topic: "Market data",
  layer: "Sources",
  nodes: 42,
  links: 18,
  health: 96,
  status: "Synced",
  updated: "2m ago"
}, {
  id: 2,
  topic: "Customer signals",
  layer: "Sources",
  nodes: 28,
  links: 11,
  health: 88,
  status: "Synced",
  updated: "14m ago"
}, {
  id: 3,
  topic: "Revenue forecast",
  layer: "Metrics",
  nodes: 31,
  links: 22,
  health: 74,
  status: "Review",
  updated: "1h ago"
}, {
  id: 4,
  topic: "Churn rate",
  layer: "Metrics",
  nodes: 17,
  links: 9,
  health: 91,
  status: "Synced",
  updated: "3h ago"
}, {
  id: 5,
  topic: "Growth thesis",
  layer: "Themes",
  nodes: 12,
  links: 14,
  health: 63,
  status: "Review",
  updated: "1d ago"
}, {
  id: 6,
  topic: "Risk model",
  layer: "Themes",
  nodes: 24,
  links: 7,
  health: 81,
  status: "Synced",
  updated: "2d ago"
}];
function Panel({
  title,
  action,
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface-card)",
      border: "1px solid var(--border-default)",
      borderRadius: "var(--radius-md)",
      boxShadow: "var(--shadow-sm)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "16px 18px 0"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-heading)",
      fontSize: 16,
      color: "var(--text-strong)"
    }
  }, title), action), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 18
    }
  }, children));
}
function App() {
  const [selected, setSelected] = React.useState(3);
  const [present, setPresent] = React.useState(false);
  const [range, setRange] = React.useState("30d");
  React.useEffect(() => {
    if (window.lucide) window.lucide.createIcons();
  });
  const statusCell = v => /*#__PURE__*/React.createElement(D.Badge, {
    tone: v === "Synced" ? "success" : "warning",
    dot: true
  }, v);
  const healthCell = v => /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 8,
      justifyContent: "flex-end",
      width: "100%"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 46,
      height: 6,
      borderRadius: 999,
      background: "var(--bg-sunken)",
      overflow: "hidden",
      display: "inline-block"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      height: "100%",
      width: v + "%",
      background: v > 85 ? "var(--success-500)" : v > 70 ? "var(--warning-500)" : "var(--danger-500)",
      borderRadius: 999
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 12
    }
  }, v));
  return /*#__PURE__*/React.createElement("div", {
    "data-theme": present ? "presentation" : undefined,
    style: {
      minHeight: "100vh",
      background: "var(--bg-app)",
      fontFamily: "var(--font-sans)",
      transition: "background-color var(--dur-slow) var(--ease-soft)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1080,
      margin: "0 auto",
      padding: present ? "48px 40px" : "28px 32px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-end",
      justifyContent: "space-between",
      gap: 16,
      marginBottom: 22
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 9,
      marginBottom: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 24,
      height: 24,
      borderRadius: 6,
      background: "var(--green-500)",
      color: "#fff",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      fontFamily: "var(--font-display)",
      fontWeight: 600,
      fontSize: 15
    }
  }, "D"), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-overline)",
      letterSpacing: "var(--tracking-caps)",
      textTransform: "uppercase",
      color: "var(--text-faint)"
    }
  }, "Insights")), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontFamily: "var(--font-display)",
      fontWeight: 600,
      fontSize: present ? 42 : 34,
      color: "var(--text-strong)",
      letterSpacing: "-0.01em"
    }
  }, "Strategy map overview")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 14
    }
  }, !present && /*#__PURE__*/React.createElement(D.SegmentedControl, {
    size: "sm",
    value: range,
    onChange: setRange,
    items: [{
      id: "7d",
      label: "7d"
    }, {
      id: "30d",
      label: "30d"
    }, {
      id: "qtr",
      label: "Quarter"
    }]
  }), /*#__PURE__*/React.createElement(D.Switch, {
    checked: present,
    onChange: setPresent,
    label: "Presentation"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(4,1fr)",
      gap: 14,
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement(D.StatCard, {
    label: "Total nodes",
    value: "248",
    delta: "12%",
    trend: "up"
  }), /*#__PURE__*/React.createElement(D.StatCard, {
    label: "Connections",
    value: "612",
    delta: "6%",
    trend: "up",
    accent: "slate"
  }), /*#__PURE__*/React.createElement(D.StatCard, {
    label: "Avg. health",
    value: "82",
    unit: "%",
    delta: "1.4",
    trend: "down",
    accent: "stone"
  }), /*#__PURE__*/React.createElement(D.StatCard, {
    label: "In review",
    value: "2",
    delta: "1",
    trend: "down",
    footnote: "topics flagged"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1.5fr 1fr",
      gap: 16,
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement(Panel, {
    title: "Nodes added",
    action: /*#__PURE__*/React.createElement(D.Badge, {
      tone: "green"
    }, range)
  }, /*#__PURE__*/React.createElement(Trend, null)), /*#__PURE__*/React.createElement(Panel, {
    title: "Coverage by layer"
  }, /*#__PURE__*/React.createElement(D.MetricBars, {
    data: [{
      label: "Sources",
      value: 70,
      color: "var(--green-500)"
    }, {
      label: "Metrics",
      value: 48,
      color: "var(--slate-500)"
    }, {
      label: "Themes",
      value: 36,
      color: "var(--stone-500)"
    }]
  }))), /*#__PURE__*/React.createElement(Panel, {
    title: "Topics",
    action: !present && /*#__PURE__*/React.createElement(D.Button, {
      variant: "secondary",
      size: "sm",
      iconLeft: /*#__PURE__*/React.createElement(Ic, {
        n: "sliders-horizontal",
        s: 14
      })
    }, "Filter")
  }, /*#__PURE__*/React.createElement(D.DataTable, {
    selectable: true,
    selectedId: selected,
    onRowClick: r => setSelected(r.id),
    columns: [{
      key: "topic",
      label: "Topic",
      render: (v, r) => /*#__PURE__*/React.createElement("span", {
        style: {
          display: "inline-flex",
          alignItems: "center",
          gap: 9
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          width: 8,
          height: 8,
          borderRadius: 3,
          background: r.layer === "Sources" ? "var(--green-500)" : r.layer === "Metrics" ? "var(--slate-500)" : "var(--stone-500)"
        }
      }), v)
    }, {
      key: "layer",
      label: "Layer"
    }, {
      key: "nodes",
      label: "Nodes",
      align: "right",
      mono: true
    }, {
      key: "links",
      label: "Links",
      align: "right",
      mono: true
    }, {
      key: "health",
      label: "Health",
      align: "right",
      render: healthCell
    }, {
      key: "status",
      label: "Status",
      render: statusCell
    }, {
      key: "updated",
      label: "Updated",
      align: "right",
      render: v => /*#__PURE__*/React.createElement("span", {
        style: {
          color: "var(--text-faint)"
        }
      }, v)
    }],
    rows: TOPICS
  }))));
}

/* tiny inline area-trend sparkline built from divs (no canvas) */
function Trend() {
  const pts = [12, 18, 15, 24, 22, 30, 27, 35, 33, 42, 40, 48];
  const max = Math.max(...pts);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-end",
      gap: 6,
      height: 150
    }
  }, pts.map((p, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      flex: 1,
      display: "flex",
      flexDirection: "column",
      justifyContent: "flex-end",
      height: "100%"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: p / max * 100 + "%",
      background: i === pts.length - 1 ? "var(--green-500)" : "var(--green-100)",
      borderRadius: "4px 4px 2px 2px",
      transition: "height var(--dur-slow) var(--ease-out)"
    }
  }))));
}
ReactDOM.createRoot(document.getElementById("root")).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/insights/app.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Connection = __ds_scope.Connection;

__ds_ns.Node = __ds_scope.Node;

__ds_ns.Toolbar = __ds_scope.Toolbar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.SegmentedControl = __ds_scope.SegmentedControl;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.DataTable = __ds_scope.DataTable;

__ds_ns.MetricBars = __ds_scope.MetricBars;

__ds_ns.StatCard = __ds_scope.StatCard;

})();
